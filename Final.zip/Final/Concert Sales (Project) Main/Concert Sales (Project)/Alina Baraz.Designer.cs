﻿namespace Concert_Sales__Project_
{
    partial class frmAlinaBaraz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAlinaBaraz));
            this.lblDate = new System.Windows.Forms.Label();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.btnBuyTickets = new System.Windows.Forms.Button();
            this.lblArtistInfo = new System.Windows.Forms.Label();
            this.lblArtistInformationBH = new System.Windows.Forms.Label();
            this.picboxBH = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.Black;
            this.lblDate.Location = new System.Drawing.Point(34, 12);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(299, 209);
            this.lblDate.TabIndex = 10;
            this.lblDate.Text = resources.GetString("lblDate.Text");
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // btnGoBack
            // 
            this.btnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnGoBack.Location = new System.Drawing.Point(12, 541);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(110, 27);
            this.btnGoBack.TabIndex = 8;
            this.btnGoBack.Text = "Go Back";
            this.btnGoBack.UseVisualStyleBackColor = true;
            this.btnGoBack.Click += new System.EventHandler(this.btnGoBack_Click);
            // 
            // btnBuyTickets
            // 
            this.btnBuyTickets.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnBuyTickets.Location = new System.Drawing.Point(48, 380);
            this.btnBuyTickets.Name = "btnBuyTickets";
            this.btnBuyTickets.Size = new System.Drawing.Size(188, 46);
            this.btnBuyTickets.TabIndex = 9;
            this.btnBuyTickets.Text = "Buy Tickets";
            this.btnBuyTickets.UseVisualStyleBackColor = true;
            this.btnBuyTickets.Click += new System.EventHandler(this.btnBuyTickets_Click);
            // 
            // lblArtistInfo
            // 
            this.lblArtistInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblArtistInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArtistInfo.ForeColor = System.Drawing.Color.Black;
            this.lblArtistInfo.Location = new System.Drawing.Point(384, 283);
            this.lblArtistInfo.Name = "lblArtistInfo";
            this.lblArtistInfo.Size = new System.Drawing.Size(342, 49);
            this.lblArtistInfo.TabIndex = 7;
            this.lblArtistInfo.Text = "Artist Information";
            this.lblArtistInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblArtistInfo.Click += new System.EventHandler(this.lblArtistInfo_Click);
            // 
            // lblArtistInformationBH
            // 
            this.lblArtistInformationBH.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArtistInformationBH.ForeColor = System.Drawing.Color.Black;
            this.lblArtistInformationBH.Location = new System.Drawing.Point(385, 332);
            this.lblArtistInformationBH.Name = "lblArtistInformationBH";
            this.lblArtistInformationBH.Size = new System.Drawing.Size(341, 215);
            this.lblArtistInformationBH.TabIndex = 6;
            this.lblArtistInformationBH.Text = resources.GetString("lblArtistInformationBH.Text");
            this.lblArtistInformationBH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblArtistInformationBH.Click += new System.EventHandler(this.lblArtistInformationBH_Click);
            // 
            // picboxBH
            // 
            this.picboxBH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picboxBH.Image = ((System.Drawing.Image)(resources.GetObject("picboxBH.Image")));
            this.picboxBH.Location = new System.Drawing.Point(380, 12);
            this.picboxBH.Name = "picboxBH";
            this.picboxBH.Size = new System.Drawing.Size(346, 255);
            this.picboxBH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBH.TabIndex = 5;
            this.picboxBH.TabStop = false;
            // 
            // frmAlinaBaraz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(743, 580);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.btnBuyTickets);
            this.Controls.Add(this.lblArtistInfo);
            this.Controls.Add(this.lblArtistInformationBH);
            this.Controls.Add(this.picboxBH);
            this.Name = "frmAlinaBaraz";
            this.Text = "Alina Baraz";
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.Button btnBuyTickets;
        private System.Windows.Forms.Label lblArtistInfo;
        private System.Windows.Forms.Label lblArtistInformationBH;
        private System.Windows.Forms.PictureBox picboxBH;
    }
}