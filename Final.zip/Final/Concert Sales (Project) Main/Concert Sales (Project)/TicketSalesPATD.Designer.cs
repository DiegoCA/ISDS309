﻿namespace Concert_Sales__Project_
{
    partial class frmTicketSalesPATD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTicketSalesPATD));
            this.numTix = new System.Windows.Forms.NumericUpDown();
            this.lblVIPAmount = new System.Windows.Forms.Label();
            this.lblBalconyVIP = new System.Windows.Forms.Label();
            this.lblGeneralAmount = new System.Windows.Forms.Label();
            this.dateExpirationDate = new System.Windows.Forms.DateTimePicker();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtSecurity = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.lblStreetAddress = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtCardNum = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblExpirationDate = new System.Windows.Forms.Label();
            this.lblSecurityCode = new System.Windows.Forms.Label();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblCheckoutPage = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.lblGenAdminPrice = new System.Windows.Forms.Label();
            this.lblBalconyPrice = new System.Windows.Forms.Label();
            this.lblVipPrice = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnFindTix = new System.Windows.Forms.Button();
            this.lblActName = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblBillingAddress = new System.Windows.Forms.Label();
            this.lblPaymentInformation = new System.Windows.Forms.Label();
            this.lblCustomerInfo = new System.Windows.Forms.Label();
            this.lbltixamount = new System.Windows.Forms.Label();
            this.rdobtnVIP = new System.Windows.Forms.RadioButton();
            this.rdobtnBalcony = new System.Windows.Forms.RadioButton();
            this.rdobtnGeneral = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.lblGeneralPrice = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblSelectPrice = new System.Windows.Forms.Label();
            this.lblbackground2 = new System.Windows.Forms.Label();
            this.lblbackground = new System.Windows.Forms.Label();
            this.lblCreditType = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).BeginInit();
            this.SuspendLayout();
            // 
            // numTix
            // 
            this.numTix.Location = new System.Drawing.Point(193, 160);
            this.numTix.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numTix.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTix.Name = "numTix";
            this.numTix.Size = new System.Drawing.Size(112, 20);
            this.numTix.TabIndex = 25;
            this.numTix.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblVIPAmount
            // 
            this.lblVIPAmount.AutoSize = true;
            this.lblVIPAmount.BackColor = System.Drawing.Color.Silver;
            this.lblVIPAmount.Location = new System.Drawing.Point(244, 291);
            this.lblVIPAmount.Name = "lblVIPAmount";
            this.lblVIPAmount.Size = new System.Drawing.Size(0, 13);
            this.lblVIPAmount.TabIndex = 75;
            // 
            // lblBalconyVIP
            // 
            this.lblBalconyVIP.AutoSize = true;
            this.lblBalconyVIP.BackColor = System.Drawing.Color.LightGray;
            this.lblBalconyVIP.Location = new System.Drawing.Point(244, 263);
            this.lblBalconyVIP.Name = "lblBalconyVIP";
            this.lblBalconyVIP.Size = new System.Drawing.Size(0, 13);
            this.lblBalconyVIP.TabIndex = 74;
            // 
            // lblGeneralAmount
            // 
            this.lblGeneralAmount.AutoSize = true;
            this.lblGeneralAmount.BackColor = System.Drawing.Color.Silver;
            this.lblGeneralAmount.Location = new System.Drawing.Point(244, 235);
            this.lblGeneralAmount.Name = "lblGeneralAmount";
            this.lblGeneralAmount.Size = new System.Drawing.Size(0, 13);
            this.lblGeneralAmount.TabIndex = 73;
            // 
            // dateExpirationDate
            // 
            this.dateExpirationDate.Enabled = false;
            this.dateExpirationDate.Location = new System.Drawing.Point(581, 410);
            this.dateExpirationDate.Margin = new System.Windows.Forms.Padding(2);
            this.dateExpirationDate.MinDate = new System.DateTime(2018, 5, 3, 0, 0, 0, 0);
            this.dateExpirationDate.Name = "dateExpirationDate";
            this.dateExpirationDate.Size = new System.Drawing.Size(198, 20);
            this.dateExpirationDate.TabIndex = 58;
            this.dateExpirationDate.Value = new System.DateTime(2018, 5, 3, 1, 28, 34, 0);
            this.dateExpirationDate.Visible = false;
            this.dateExpirationDate.ValueChanged += new System.EventHandler(this.dateExpirationDate_ValueChanged);
            // 
            // txtState
            // 
            this.txtState.Enabled = false;
            this.txtState.Location = new System.Drawing.Point(805, 276);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(144, 20);
            this.txtState.TabIndex = 49;
            this.txtState.Visible = false;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            // 
            // txtStreet
            // 
            this.txtStreet.Enabled = false;
            this.txtStreet.Location = new System.Drawing.Point(805, 223);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(144, 20);
            this.txtStreet.TabIndex = 39;
            this.txtStreet.Visible = false;
            this.txtStreet.TextChanged += new System.EventHandler(this.txtStreet_TextChanged);
            // 
            // txtZip
            // 
            this.txtZip.Enabled = false;
            this.txtZip.Location = new System.Drawing.Point(599, 329);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(144, 20);
            this.txtZip.TabIndex = 51;
            this.txtZip.Visible = false;
            this.txtZip.TextChanged += new System.EventHandler(this.txtZip_TextChanged);
            // 
            // txtCity
            // 
            this.txtCity.Enabled = false;
            this.txtCity.Location = new System.Drawing.Point(599, 276);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(144, 20);
            this.txtCity.TabIndex = 42;
            this.txtCity.Visible = false;
            this.txtCity.TextChanged += new System.EventHandler(this.txtCity_TextChanged);
            // 
            // txtCountry
            // 
            this.txtCountry.Enabled = false;
            this.txtCountry.Location = new System.Drawing.Point(599, 223);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(144, 20);
            this.txtCountry.TabIndex = 33;
            this.txtCountry.Visible = false;
            this.txtCountry.TextChanged += new System.EventHandler(this.txtCountry_TextChanged);
            // 
            // txtSecurity
            // 
            this.txtSecurity.Enabled = false;
            this.txtSecurity.Location = new System.Drawing.Point(909, 417);
            this.txtSecurity.MaxLength = 3;
            this.txtSecurity.Name = "txtSecurity";
            this.txtSecurity.Size = new System.Drawing.Size(40, 20);
            this.txtSecurity.TabIndex = 59;
            this.txtSecurity.UseSystemPasswordChar = true;
            this.txtSecurity.Visible = false;
            this.txtSecurity.TextChanged += new System.EventHandler(this.txtSecurity_TextChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Enabled = false;
            this.txtEmail.Location = new System.Drawing.Point(805, 143);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(144, 20);
            this.txtEmail.TabIndex = 32;
            this.txtEmail.Visible = false;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.BackColor = System.Drawing.Color.Silver;
            this.lblState.ForeColor = System.Drawing.Color.Black;
            this.lblState.Location = new System.Drawing.Point(805, 253);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(35, 13);
            this.lblState.TabIndex = 72;
            this.lblState.Text = "State:";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblState.Visible = false;
            // 
            // lblZipCode
            // 
            this.lblZipCode.AutoSize = true;
            this.lblZipCode.BackColor = System.Drawing.Color.Silver;
            this.lblZipCode.ForeColor = System.Drawing.Color.Black;
            this.lblZipCode.Location = new System.Drawing.Point(599, 306);
            this.lblZipCode.Name = "lblZipCode";
            this.lblZipCode.Size = new System.Drawing.Size(52, 13);
            this.lblZipCode.TabIndex = 67;
            this.lblZipCode.Text = "Zip code:";
            this.lblZipCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblZipCode.Visible = false;
            // 
            // lblStreetAddress
            // 
            this.lblStreetAddress.AutoSize = true;
            this.lblStreetAddress.BackColor = System.Drawing.Color.Silver;
            this.lblStreetAddress.ForeColor = System.Drawing.Color.Black;
            this.lblStreetAddress.Location = new System.Drawing.Point(805, 200);
            this.lblStreetAddress.Name = "lblStreetAddress";
            this.lblStreetAddress.Size = new System.Drawing.Size(79, 13);
            this.lblStreetAddress.TabIndex = 71;
            this.lblStreetAddress.Text = "Street Address:";
            this.lblStreetAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStreetAddress.Visible = false;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.BackColor = System.Drawing.Color.Silver;
            this.lblCity.ForeColor = System.Drawing.Color.Black;
            this.lblCity.Location = new System.Drawing.Point(599, 253);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(27, 13);
            this.lblCity.TabIndex = 66;
            this.lblCity.Text = "City:";
            this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCity.Visible = false;
            // 
            // txtCardNum
            // 
            this.txtCardNum.Enabled = false;
            this.txtCardNum.Location = new System.Drawing.Point(805, 387);
            this.txtCardNum.MaxLength = 19;
            this.txtCardNum.Name = "txtCardNum";
            this.txtCardNum.Size = new System.Drawing.Size(144, 20);
            this.txtCardNum.TabIndex = 56;
            this.txtCardNum.Visible = false;
            this.txtCardNum.TextChanged += new System.EventHandler(this.txtCardNum_TextChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(599, 143);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(144, 20);
            this.txtName.TabIndex = 31;
            this.txtName.Visible = false;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.BackColor = System.Drawing.Color.Silver;
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(599, 200);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(46, 13);
            this.lblCountry.TabIndex = 65;
            this.lblCountry.Text = "Country:";
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCountry.Visible = false;
            // 
            // lblExpirationDate
            // 
            this.lblExpirationDate.AutoSize = true;
            this.lblExpirationDate.BackColor = System.Drawing.Color.LightGray;
            this.lblExpirationDate.ForeColor = System.Drawing.Color.Black;
            this.lblExpirationDate.Location = new System.Drawing.Point(580, 387);
            this.lblExpirationDate.Name = "lblExpirationDate";
            this.lblExpirationDate.Size = new System.Drawing.Size(82, 13);
            this.lblExpirationDate.TabIndex = 70;
            this.lblExpirationDate.Text = "Expiration Date:";
            this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblExpirationDate.Visible = false;
            // 
            // lblSecurityCode
            // 
            this.lblSecurityCode.AutoSize = true;
            this.lblSecurityCode.BackColor = System.Drawing.Color.LightGray;
            this.lblSecurityCode.ForeColor = System.Drawing.Color.Black;
            this.lblSecurityCode.Location = new System.Drawing.Point(808, 416);
            this.lblSecurityCode.Name = "lblSecurityCode";
            this.lblSecurityCode.Size = new System.Drawing.Size(76, 13);
            this.lblSecurityCode.TabIndex = 69;
            this.lblSecurityCode.Text = "Security Code:";
            this.lblSecurityCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSecurityCode.Visible = false;
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.AutoSize = true;
            this.lblCardNumber.BackColor = System.Drawing.Color.LightGray;
            this.lblCardNumber.ForeColor = System.Drawing.Color.Black;
            this.lblCardNumber.Location = new System.Drawing.Point(805, 371);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(72, 13);
            this.lblCardNumber.TabIndex = 64;
            this.lblCardNumber.Text = "Card Number:";
            this.lblCardNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCardNumber.Visible = false;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.LightGray;
            this.lblEmail.ForeColor = System.Drawing.Color.Black;
            this.lblEmail.Location = new System.Drawing.Point(805, 123);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(38, 13);
            this.lblEmail.TabIndex = 68;
            this.lblEmail.Text = "Email: ";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEmail.Visible = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.LightGray;
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(599, 123);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(57, 13);
            this.lblName.TabIndex = 63;
            this.lblName.Text = "Full Name:";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblName.Visible = false;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label13.Location = new System.Drawing.Point(504, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 448);
            this.label13.TabIndex = 61;
            this.label13.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|";
            // 
            // lblCheckoutPage
            // 
            this.lblCheckoutPage.BackColor = System.Drawing.Color.Gainsboro;
            this.lblCheckoutPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckoutPage.ForeColor = System.Drawing.Color.Black;
            this.lblCheckoutPage.Location = new System.Drawing.Point(568, 36);
            this.lblCheckoutPage.Name = "lblCheckoutPage";
            this.lblCheckoutPage.Size = new System.Drawing.Size(423, 45);
            this.lblCheckoutPage.TabIndex = 60;
            this.lblCheckoutPage.Text = "Checkout Page";
            this.lblCheckoutPage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCheckoutPage.Visible = false;
            // 
            // lblFees
            // 
            this.lblFees.AutoSize = true;
            this.lblFees.BackColor = System.Drawing.Color.Silver;
            this.lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFees.Location = new System.Drawing.Point(53, 408);
            this.lblFees.Name = "lblFees";
            this.lblFees.Size = new System.Drawing.Size(76, 12);
            this.lblFees.TabIndex = 57;
            this.lblFees.Text = "*All fees included";
            this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGenAdminPrice
            // 
            this.lblGenAdminPrice.AutoSize = true;
            this.lblGenAdminPrice.BackColor = System.Drawing.Color.Silver;
            this.lblGenAdminPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenAdminPrice.Location = new System.Drawing.Point(354, 232);
            this.lblGenAdminPrice.Name = "lblGenAdminPrice";
            this.lblGenAdminPrice.Size = new System.Drawing.Size(52, 16);
            this.lblGenAdminPrice.TabIndex = 52;
            this.lblGenAdminPrice.Text = "$35.00";
            this.lblGenAdminPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBalconyPrice
            // 
            this.lblBalconyPrice.AutoSize = true;
            this.lblBalconyPrice.BackColor = System.Drawing.Color.LightGray;
            this.lblBalconyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalconyPrice.Location = new System.Drawing.Point(354, 260);
            this.lblBalconyPrice.Name = "lblBalconyPrice";
            this.lblBalconyPrice.Size = new System.Drawing.Size(52, 16);
            this.lblBalconyPrice.TabIndex = 53;
            this.lblBalconyPrice.Text = "$35.00";
            this.lblBalconyPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVipPrice
            // 
            this.lblVipPrice.AutoSize = true;
            this.lblVipPrice.BackColor = System.Drawing.Color.Silver;
            this.lblVipPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVipPrice.Location = new System.Drawing.Point(354, 288);
            this.lblVipPrice.Name = "lblVipPrice";
            this.lblVipPrice.Size = new System.Drawing.Size(52, 16);
            this.lblVipPrice.TabIndex = 54;
            this.lblVipPrice.Text = "$70.00";
            this.lblVipPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Silver;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(193, 381);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(213, 35);
            this.lblResults.TabIndex = 55;
            this.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Enabled = false;
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(713, 461);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(131, 23);
            this.btnConfirm.TabIndex = 62;
            this.btnConfirm.Text = "Confirm Purchase";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Visible = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Enabled = false;
            this.btnCheckOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.Location = new System.Drawing.Point(342, 461);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(112, 23);
            this.btnCheckOut.TabIndex = 30;
            this.btnCheckOut.Text = "Checkout";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(44, 461);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 23);
            this.btnCancel.TabIndex = 50;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFindTix
            // 
            this.btnFindTix.BackColor = System.Drawing.Color.Gainsboro;
            this.btnFindTix.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindTix.Location = new System.Drawing.Point(193, 328);
            this.btnFindTix.Name = "btnFindTix";
            this.btnFindTix.Size = new System.Drawing.Size(112, 23);
            this.btnFindTix.TabIndex = 29;
            this.btnFindTix.Text = "Find Tickets";
            this.btnFindTix.UseVisualStyleBackColor = false;
            this.btnFindTix.Click += new System.EventHandler(this.btnFindTix_Click);
            // 
            // lblActName
            // 
            this.lblActName.BackColor = System.Drawing.Color.Silver;
            this.lblActName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblActName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActName.ForeColor = System.Drawing.Color.Black;
            this.lblActName.Location = new System.Drawing.Point(219, 36);
            this.lblActName.Name = "lblActName";
            this.lblActName.Size = new System.Drawing.Size(235, 70);
            this.lblActName.TabIndex = 47;
            this.lblActName.Text = "Panic! At The Disco";
            this.lblActName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.Color.Silver;
            this.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.Black;
            this.lblDate.Location = new System.Drawing.Point(44, 36);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(85, 70);
            this.lblDate.TabIndex = 48;
            this.lblDate.Text = "MAY\r\n10";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBillingAddress
            // 
            this.lblBillingAddress.BackColor = System.Drawing.Color.Silver;
            this.lblBillingAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillingAddress.ForeColor = System.Drawing.Color.Black;
            this.lblBillingAddress.Location = new System.Drawing.Point(565, 172);
            this.lblBillingAddress.Name = "lblBillingAddress";
            this.lblBillingAddress.Size = new System.Drawing.Size(426, 185);
            this.lblBillingAddress.TabIndex = 43;
            this.lblBillingAddress.Text = "Billing Address:";
            this.lblBillingAddress.Visible = false;
            // 
            // lblPaymentInformation
            // 
            this.lblPaymentInformation.BackColor = System.Drawing.Color.LightGray;
            this.lblPaymentInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentInformation.ForeColor = System.Drawing.Color.Black;
            this.lblPaymentInformation.Location = new System.Drawing.Point(565, 357);
            this.lblPaymentInformation.Name = "lblPaymentInformation";
            this.lblPaymentInformation.Size = new System.Drawing.Size(426, 86);
            this.lblPaymentInformation.TabIndex = 46;
            this.lblPaymentInformation.Text = "Payment Information:";
            this.lblPaymentInformation.Visible = false;
            // 
            // lblCustomerInfo
            // 
            this.lblCustomerInfo.BackColor = System.Drawing.Color.LightGray;
            this.lblCustomerInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerInfo.ForeColor = System.Drawing.Color.Black;
            this.lblCustomerInfo.Location = new System.Drawing.Point(565, 97);
            this.lblCustomerInfo.Name = "lblCustomerInfo";
            this.lblCustomerInfo.Size = new System.Drawing.Size(426, 75);
            this.lblCustomerInfo.TabIndex = 45;
            this.lblCustomerInfo.Text = "Customer Information:";
            this.lblCustomerInfo.Visible = false;
            // 
            // lbltixamount
            // 
            this.lbltixamount.BackColor = System.Drawing.Color.Gainsboro;
            this.lbltixamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltixamount.ForeColor = System.Drawing.Color.Black;
            this.lbltixamount.Location = new System.Drawing.Point(44, 117);
            this.lbltixamount.Name = "lbltixamount";
            this.lbltixamount.Size = new System.Drawing.Size(410, 40);
            this.lbltixamount.TabIndex = 44;
            this.lbltixamount.Text = "How many tickets are you looking for?";
            this.lbltixamount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rdobtnVIP
            // 
            this.rdobtnVIP.AutoSize = true;
            this.rdobtnVIP.BackColor = System.Drawing.Color.Silver;
            this.rdobtnVIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnVIP.ForeColor = System.Drawing.Color.Black;
            this.rdobtnVIP.Location = new System.Drawing.Point(56, 286);
            this.rdobtnVIP.Name = "rdobtnVIP";
            this.rdobtnVIP.Size = new System.Drawing.Size(47, 20);
            this.rdobtnVIP.TabIndex = 28;
            this.rdobtnVIP.TabStop = true;
            this.rdobtnVIP.Text = "VIP";
            this.rdobtnVIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnVIP.UseVisualStyleBackColor = false;
            // 
            // rdobtnBalcony
            // 
            this.rdobtnBalcony.AutoSize = true;
            this.rdobtnBalcony.BackColor = System.Drawing.Color.LightGray;
            this.rdobtnBalcony.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnBalcony.ForeColor = System.Drawing.Color.Black;
            this.rdobtnBalcony.Location = new System.Drawing.Point(56, 258);
            this.rdobtnBalcony.Name = "rdobtnBalcony";
            this.rdobtnBalcony.Size = new System.Drawing.Size(75, 20);
            this.rdobtnBalcony.TabIndex = 27;
            this.rdobtnBalcony.TabStop = true;
            this.rdobtnBalcony.Text = "Balcony";
            this.rdobtnBalcony.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnBalcony.UseVisualStyleBackColor = false;
            // 
            // rdobtnGeneral
            // 
            this.rdobtnGeneral.AutoSize = true;
            this.rdobtnGeneral.BackColor = System.Drawing.Color.Silver;
            this.rdobtnGeneral.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnGeneral.ForeColor = System.Drawing.Color.Black;
            this.rdobtnGeneral.Location = new System.Drawing.Point(56, 230);
            this.rdobtnGeneral.Name = "rdobtnGeneral";
            this.rdobtnGeneral.Size = new System.Drawing.Size(140, 20);
            this.rdobtnGeneral.TabIndex = 26;
            this.rdobtnGeneral.TabStop = true;
            this.rdobtnGeneral.Text = "General Admission";
            this.rdobtnGeneral.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnGeneral.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(410, 28);
            this.label4.TabIndex = 35;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblGeneralPrice
            // 
            this.lblGeneralPrice.BackColor = System.Drawing.Color.Silver;
            this.lblGeneralPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneralPrice.Location = new System.Drawing.Point(44, 226);
            this.lblGeneralPrice.Name = "lblGeneralPrice";
            this.lblGeneralPrice.Size = new System.Drawing.Size(410, 28);
            this.lblGeneralPrice.TabIndex = 36;
            this.lblGeneralPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(410, 28);
            this.label2.TabIndex = 41;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.BackColor = System.Drawing.Color.Silver;
            this.lblSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(44, 368);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(410, 58);
            this.lblSubTotal.TabIndex = 40;
            this.lblSubTotal.Text = "Order Total";
            this.lblSubTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSelectPrice
            // 
            this.lblSelectPrice.BackColor = System.Drawing.Color.LightGray;
            this.lblSelectPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectPrice.Location = new System.Drawing.Point(44, 198);
            this.lblSelectPrice.Name = "lblSelectPrice";
            this.lblSelectPrice.Size = new System.Drawing.Size(410, 28);
            this.lblSelectPrice.TabIndex = 38;
            this.lblSelectPrice.Text = "Select Price Level";
            this.lblSelectPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblbackground2
            // 
            this.lblbackground2.BackColor = System.Drawing.Color.Gainsboro;
            this.lblbackground2.Location = new System.Drawing.Point(44, 310);
            this.lblbackground2.Name = "lblbackground2";
            this.lblbackground2.Size = new System.Drawing.Size(410, 58);
            this.lblbackground2.TabIndex = 34;
            this.lblbackground2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblbackground
            // 
            this.lblbackground.BackColor = System.Drawing.Color.Gainsboro;
            this.lblbackground.Location = new System.Drawing.Point(44, 156);
            this.lblbackground.Name = "lblbackground";
            this.lblbackground.Size = new System.Drawing.Size(410, 42);
            this.lblbackground.TabIndex = 37;
            this.lblbackground.Text = "(4 tickets max)";
            this.lblbackground.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblCreditType
            // 
            this.lblCreditType.BackColor = System.Drawing.Color.LightGray;
            this.lblCreditType.Location = new System.Drawing.Point(699, 387);
            this.lblCreditType.Name = "lblCreditType";
            this.lblCreditType.Size = new System.Drawing.Size(100, 20);
            this.lblCreditType.TabIndex = 76;
            this.lblCreditType.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(225, 207);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 77;
            this.label1.Text = "Seats Available";
            // 
            // frmTicketSalesPATD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1034, 521);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCreditType);
            this.Controls.Add(this.numTix);
            this.Controls.Add(this.lblVIPAmount);
            this.Controls.Add(this.lblBalconyVIP);
            this.Controls.Add(this.lblGeneralAmount);
            this.Controls.Add(this.dateExpirationDate);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.txtSecurity);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblZipCode);
            this.Controls.Add(this.lblStreetAddress);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.txtCardNum);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.lblExpirationDate);
            this.Controls.Add(this.lblSecurityCode);
            this.Controls.Add(this.lblCardNumber);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblCheckoutPage);
            this.Controls.Add(this.lblFees);
            this.Controls.Add(this.lblGenAdminPrice);
            this.Controls.Add(this.lblBalconyPrice);
            this.Controls.Add(this.lblVipPrice);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnFindTix);
            this.Controls.Add(this.lblActName);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblBillingAddress);
            this.Controls.Add(this.lblPaymentInformation);
            this.Controls.Add(this.lblCustomerInfo);
            this.Controls.Add(this.lbltixamount);
            this.Controls.Add(this.rdobtnVIP);
            this.Controls.Add(this.rdobtnBalcony);
            this.Controls.Add(this.rdobtnGeneral);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblGeneralPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.lblSelectPrice);
            this.Controls.Add(this.lblbackground2);
            this.Controls.Add(this.lblbackground);
            this.Name = "frmTicketSalesPATD";
            this.Text = "Ticket Sales";
            this.Load += new System.EventHandler(this.frmTicketSalesPATD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numTix;
        private System.Windows.Forms.Label lblVIPAmount;
        private System.Windows.Forms.Label lblBalconyVIP;
        private System.Windows.Forms.Label lblGeneralAmount;
        private System.Windows.Forms.DateTimePicker dateExpirationDate;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtSecurity;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.Label lblStreetAddress;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtCardNum;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblExpirationDate;
        private System.Windows.Forms.Label lblSecurityCode;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblCheckoutPage;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Label lblGenAdminPrice;
        private System.Windows.Forms.Label lblBalconyPrice;
        private System.Windows.Forms.Label lblVipPrice;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnFindTix;
        private System.Windows.Forms.Label lblActName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblBillingAddress;
        private System.Windows.Forms.Label lblPaymentInformation;
        private System.Windows.Forms.Label lblCustomerInfo;
        private System.Windows.Forms.Label lbltixamount;
        private System.Windows.Forms.RadioButton rdobtnVIP;
        private System.Windows.Forms.RadioButton rdobtnBalcony;
        private System.Windows.Forms.RadioButton rdobtnGeneral;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblGeneralPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblSelectPrice;
        private System.Windows.Forms.Label lblbackground2;
        private System.Windows.Forms.Label lblbackground;
        private System.Windows.Forms.Label lblCreditType;
        private System.Windows.Forms.Label label1;
    }
}