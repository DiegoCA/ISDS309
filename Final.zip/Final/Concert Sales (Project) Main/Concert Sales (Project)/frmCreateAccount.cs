﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Concert_Sales__Project_
{
    public partial class frmCreateAccount : Form
    {
        public frmCreateAccount()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmMainPage secondForm = new frmMainPage();
            secondForm.Show();
            this.Hide();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string name, city, address, state, email, zip, username, password;
            const string FILENAME = "customerTemp.txt";
            const string FILENAME2 = "customerPerm.txt";
           

            // create file stream 
            FileStream outFile = new FileStream(FILENAME, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            // input from user 
            password = txtPassword.Text;
            username = txtUsername.Text;
            name = txtName.Text;
            city = txtCity.Text;
            address = txtAddres.Text;
            state = txtState.Text;
            email = txtEmail.Text;
            zip = txtZip.Text;




            if (string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtCity.Text) | string.IsNullOrEmpty(txtAddres.Text)
                || string.IsNullOrEmpty(txtState.Text) || string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtEmail.Text)
                || string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtPasswordCheck.Text))
            {

                lblError.Text = ("Please fill out all of the sections above to continue ");
                lblError.Visible = true;

            }

            else if (txtPassword.Text != txtPasswordCheck.Text)
            {
                lblError.Text = ("The passwords must match ");
                lblError.Visible = true;

            }
            else
                lblWelcome.Visible = true;
                lblError.Visible = false;
            // saving data to file

            writer.WriteLine(username);
            writer.WriteLine(password);
            writer.WriteLine(name);
            writer.WriteLine(city);
            writer.WriteLine(address);
            writer.WriteLine(email);
            writer.WriteLine(zip);
            writer.WriteLine(state);


            // perm file location
            FileStream outFile2 = new FileStream(FILENAME2, FileMode.Append, FileAccess.Write);
            StreamWriter writer2 = new StreamWriter(outFile2);

            // saving data to file
            writer2.WriteLine(username);
            writer2.WriteLine(password);
            writer2.WriteLine(name);
            writer2.WriteLine(city);
            writer2.WriteLine(address);
            writer2.WriteLine(email);
            writer2.WriteLine(zip);
            writer2.WriteLine(state);

            // close file
            writer.Close();
            outFile.Close();
            writer2.Close();
            outFile2.Close();


        }
    }
}
