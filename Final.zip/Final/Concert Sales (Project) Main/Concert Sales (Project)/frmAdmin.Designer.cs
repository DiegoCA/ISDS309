﻿namespace Concert_Sales__Project_
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.lblBROCKHAMPTON = new System.Windows.Forms.Label();
            this.lblAlina = new System.Windows.Forms.Label();
            this.lblPATD = new System.Windows.Forms.Label();
            this.lblBEYANDJ = new System.Windows.Forms.Label();
            this.lblBHGA = new System.Windows.Forms.Label();
            this.lblBHBALC = new System.Windows.Forms.Label();
            this.lblBHVIP = new System.Windows.Forms.Label();
            this.lblBHTotalSales = new System.Windows.Forms.Label();
            this.lblABGD = new System.Windows.Forms.Label();
            this.lblABBALC = new System.Windows.Forms.Label();
            this.lblABVIP = new System.Windows.Forms.Label();
            this.lblABtotalSales = new System.Windows.Forms.Label();
            this.lblPADTGA = new System.Windows.Forms.Label();
            this.lblPATDBALC = new System.Windows.Forms.Label();
            this.lblPATDVIP = new System.Windows.Forms.Label();
            this.lblPATDTotalSales = new System.Windows.Forms.Label();
            this.lblBANDJGA = new System.Windows.Forms.Label();
            this.lblBANDJBALC = new System.Windows.Forms.Label();
            this.lblBANDJVIP = new System.Windows.Forms.Label();
            this.lblBANDJTotalSales = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(12, 13);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblBROCKHAMPTON
            // 
            this.lblBROCKHAMPTON.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBROCKHAMPTON.Location = new System.Drawing.Point(73, 85);
            this.lblBROCKHAMPTON.Name = "lblBROCKHAMPTON";
            this.lblBROCKHAMPTON.Size = new System.Drawing.Size(154, 110);
            this.lblBROCKHAMPTON.TabIndex = 5;
            // 
            // lblAlina
            // 
            this.lblAlina.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAlina.Location = new System.Drawing.Point(338, 85);
            this.lblAlina.Name = "lblAlina";
            this.lblAlina.Size = new System.Drawing.Size(154, 110);
            this.lblAlina.TabIndex = 6;
            // 
            // lblPATD
            // 
            this.lblPATD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPATD.Location = new System.Drawing.Point(73, 214);
            this.lblPATD.Name = "lblPATD";
            this.lblPATD.Size = new System.Drawing.Size(154, 110);
            this.lblPATD.TabIndex = 7;
            // 
            // lblBEYANDJ
            // 
            this.lblBEYANDJ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBEYANDJ.Location = new System.Drawing.Point(338, 214);
            this.lblBEYANDJ.Name = "lblBEYANDJ";
            this.lblBEYANDJ.Size = new System.Drawing.Size(154, 110);
            this.lblBEYANDJ.TabIndex = 8;
            // 
            // lblBHGA
            // 
            this.lblBHGA.AutoSize = true;
            this.lblBHGA.Location = new System.Drawing.Point(166, 94);
            this.lblBHGA.Name = "lblBHGA";
            this.lblBHGA.Size = new System.Drawing.Size(0, 13);
            this.lblBHGA.TabIndex = 11;
            // 
            // lblBHBALC
            // 
            this.lblBHBALC.AutoSize = true;
            this.lblBHBALC.Location = new System.Drawing.Point(166, 120);
            this.lblBHBALC.Name = "lblBHBALC";
            this.lblBHBALC.Size = new System.Drawing.Size(0, 13);
            this.lblBHBALC.TabIndex = 11;
            // 
            // lblBHVIP
            // 
            this.lblBHVIP.AutoSize = true;
            this.lblBHVIP.Location = new System.Drawing.Point(166, 146);
            this.lblBHVIP.Name = "lblBHVIP";
            this.lblBHVIP.Size = new System.Drawing.Size(0, 13);
            this.lblBHVIP.TabIndex = 11;
            // 
            // lblBHTotalSales
            // 
            this.lblBHTotalSales.AutoSize = true;
            this.lblBHTotalSales.Location = new System.Drawing.Point(166, 170);
            this.lblBHTotalSales.Name = "lblBHTotalSales";
            this.lblBHTotalSales.Size = new System.Drawing.Size(0, 13);
            this.lblBHTotalSales.TabIndex = 11;
            // 
            // lblABGD
            // 
            this.lblABGD.AutoSize = true;
            this.lblABGD.Location = new System.Drawing.Point(436, 94);
            this.lblABGD.Name = "lblABGD";
            this.lblABGD.Size = new System.Drawing.Size(0, 13);
            this.lblABGD.TabIndex = 12;
            // 
            // lblABBALC
            // 
            this.lblABBALC.AutoSize = true;
            this.lblABBALC.Location = new System.Drawing.Point(436, 121);
            this.lblABBALC.Name = "lblABBALC";
            this.lblABBALC.Size = new System.Drawing.Size(0, 13);
            this.lblABBALC.TabIndex = 12;
            // 
            // lblABVIP
            // 
            this.lblABVIP.AutoSize = true;
            this.lblABVIP.Location = new System.Drawing.Point(436, 147);
            this.lblABVIP.Name = "lblABVIP";
            this.lblABVIP.Size = new System.Drawing.Size(0, 13);
            this.lblABVIP.TabIndex = 12;
            // 
            // lblABtotalSales
            // 
            this.lblABtotalSales.AutoSize = true;
            this.lblABtotalSales.Location = new System.Drawing.Point(436, 173);
            this.lblABtotalSales.Name = "lblABtotalSales";
            this.lblABtotalSales.Size = new System.Drawing.Size(0, 13);
            this.lblABtotalSales.TabIndex = 12;
            // 
            // lblPADTGA
            // 
            this.lblPADTGA.AutoSize = true;
            this.lblPADTGA.Location = new System.Drawing.Point(180, 219);
            this.lblPADTGA.Name = "lblPADTGA";
            this.lblPADTGA.Size = new System.Drawing.Size(0, 13);
            this.lblPADTGA.TabIndex = 13;
            // 
            // lblPATDBALC
            // 
            this.lblPATDBALC.AutoSize = true;
            this.lblPATDBALC.Location = new System.Drawing.Point(180, 252);
            this.lblPATDBALC.Name = "lblPATDBALC";
            this.lblPATDBALC.Size = new System.Drawing.Size(0, 13);
            this.lblPATDBALC.TabIndex = 13;
            // 
            // lblPATDVIP
            // 
            this.lblPATDVIP.AutoSize = true;
            this.lblPATDVIP.Location = new System.Drawing.Point(180, 281);
            this.lblPATDVIP.Name = "lblPATDVIP";
            this.lblPATDVIP.Size = new System.Drawing.Size(0, 13);
            this.lblPATDVIP.TabIndex = 13;
            // 
            // lblPATDTotalSales
            // 
            this.lblPATDTotalSales.AutoSize = true;
            this.lblPATDTotalSales.Location = new System.Drawing.Point(180, 307);
            this.lblPATDTotalSales.Name = "lblPATDTotalSales";
            this.lblPATDTotalSales.Size = new System.Drawing.Size(0, 13);
            this.lblPATDTotalSales.TabIndex = 13;
            // 
            // lblBANDJGA
            // 
            this.lblBANDJGA.AutoSize = true;
            this.lblBANDJGA.Location = new System.Drawing.Point(436, 219);
            this.lblBANDJGA.Name = "lblBANDJGA";
            this.lblBANDJGA.Size = new System.Drawing.Size(0, 13);
            this.lblBANDJGA.TabIndex = 14;
            // 
            // lblBANDJBALC
            // 
            this.lblBANDJBALC.AutoSize = true;
            this.lblBANDJBALC.Location = new System.Drawing.Point(436, 247);
            this.lblBANDJBALC.Name = "lblBANDJBALC";
            this.lblBANDJBALC.Size = new System.Drawing.Size(0, 13);
            this.lblBANDJBALC.TabIndex = 14;
            // 
            // lblBANDJVIP
            // 
            this.lblBANDJVIP.AutoSize = true;
            this.lblBANDJVIP.Location = new System.Drawing.Point(436, 275);
            this.lblBANDJVIP.Name = "lblBANDJVIP";
            this.lblBANDJVIP.Size = new System.Drawing.Size(0, 13);
            this.lblBANDJVIP.TabIndex = 14;
            // 
            // lblBANDJTotalSales
            // 
            this.lblBANDJTotalSales.AutoSize = true;
            this.lblBANDJTotalSales.Location = new System.Drawing.Point(436, 303);
            this.lblBANDJTotalSales.Name = "lblBANDJTotalSales";
            this.lblBANDJTotalSales.Size = new System.Drawing.Size(0, 13);
            this.lblBANDJTotalSales.TabIndex = 14;
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 425);
            this.Controls.Add(this.lblBANDJTotalSales);
            this.Controls.Add(this.lblBANDJVIP);
            this.Controls.Add(this.lblBANDJBALC);
            this.Controls.Add(this.lblBANDJGA);
            this.Controls.Add(this.lblPATDTotalSales);
            this.Controls.Add(this.lblPATDVIP);
            this.Controls.Add(this.lblPATDBALC);
            this.Controls.Add(this.lblPADTGA);
            this.Controls.Add(this.lblABtotalSales);
            this.Controls.Add(this.lblABVIP);
            this.Controls.Add(this.lblABBALC);
            this.Controls.Add(this.lblABGD);
            this.Controls.Add(this.lblBHTotalSales);
            this.Controls.Add(this.lblBHVIP);
            this.Controls.Add(this.lblBHBALC);
            this.Controls.Add(this.lblBHGA);
            this.Controls.Add(this.lblBEYANDJ);
            this.Controls.Add(this.lblPATD);
            this.Controls.Add(this.lblAlina);
            this.Controls.Add(this.lblBROCKHAMPTON);
            this.Controls.Add(this.btnBack);
            this.Name = "frmAdmin";
            this.Text = "frmAdmin";
            this.Load += new System.EventHandler(this.frmAdmin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblBROCKHAMPTON;
        private System.Windows.Forms.Label lblAlina;
        private System.Windows.Forms.Label lblPATD;
        private System.Windows.Forms.Label lblBEYANDJ;
        private System.Windows.Forms.Label lblBHGA;
        private System.Windows.Forms.Label lblBHBALC;
        private System.Windows.Forms.Label lblBHVIP;
        private System.Windows.Forms.Label lblBHTotalSales;
        private System.Windows.Forms.Label lblABGD;
        private System.Windows.Forms.Label lblABBALC;
        private System.Windows.Forms.Label lblABVIP;
        private System.Windows.Forms.Label lblABtotalSales;
        private System.Windows.Forms.Label lblPADTGA;
        private System.Windows.Forms.Label lblPATDBALC;
        private System.Windows.Forms.Label lblPATDVIP;
        private System.Windows.Forms.Label lblPATDTotalSales;
        private System.Windows.Forms.Label lblBANDJGA;
        private System.Windows.Forms.Label lblBANDJBALC;
        private System.Windows.Forms.Label lblBANDJVIP;
        private System.Windows.Forms.Label lblBANDJTotalSales;
    }
}