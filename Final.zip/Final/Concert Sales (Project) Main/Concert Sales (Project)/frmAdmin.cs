﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Concert_Sales__Project_
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmMainPage secondForm = new frmMainPage();
            secondForm.Show();
            this.Hide();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            const string FILENAME2 = "customerPerm.txt";
            // create file stream and stream reader
            FileStream inFile = new FileStream(FILENAME2, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            string line;
            int counter = 0;


            while ((line = reader.ReadLine()) != null)
            {



                if (line.Contains(txtSearch.Text))

                {

                    rtxtUsers.Text = reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();
                    rtxtUsers.Text += Environment.NewLine + reader.ReadLine();




                }
            }
        }

        private void rtxtTickets_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
