﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concert_Sales__Project_
{
    public partial class frmP_ATD : Form
    {
        public frmP_ATD()
        {
            InitializeComponent();
        }

        private void btnBuyTickets_Click(object sender, EventArgs e)
        {
            frmP_ATD secondForm = new frmP_ATD();
            secondForm.Show();
            this.Hide();
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmEvents thirdForm = new frmEvents();
            thirdForm.Show();
            this.Hide();
        }
    }
}
