﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concert_Sales__Project_
{
    public partial class frmEvents : Form
    {
        public frmEvents()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMainPage secondForm = new frmMainPage();
            secondForm.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void picboxBH_Click(object sender, EventArgs e)
        {
            frmBrockhampton thirdForm = new frmBrockhampton();
            thirdForm.Show();
            this.Hide();
        }

        private void picBoxAlinaBaraz_Click(object sender, EventArgs e)
        {
            frmAlinaBaraz fourthForm = new frmAlinaBaraz();
            fourthForm.Show();
            this.Hide();
        }

        private void picBoxPanic_Click(object sender, EventArgs e)
        {
            frmP_ATD fifthForm = new frmP_ATD();
            fifthForm.Show();
            this.Hide();
        }

        private void picBoxBeyonce_Click(object sender, EventArgs e)
        {
            frmBeyAndJay sixthForm = new frmBeyAndJay();
            sixthForm.Show();
            this.Hide();
        }
    }
}
