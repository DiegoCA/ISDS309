﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;
using System.IO;

namespace Concert_Sales__Project_
{
    public partial class frmTicketSalesAlina : Form
    {
        public frmTicketSalesAlina()
        {
            InitializeComponent();

        }

        private void frmTicketSalesAlina_Load(object sender, EventArgs e)
        {
            // Declare variables and constants
            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;
            const string FILENAME_PERM = "seatPermanentAB.txt";

            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());


            // Display results
            lblGeneralAmount.Text = String.Format("{0}", generalSeatsAvailable);
            lblBalconyVIP.Text = String.Format("{0}", balconySeatsAvailable);
            lblVIPAmount.Text = String.Format("{0}", vipSeatsAvailable);

            reader.Close();
            inFile.Close();
        }

        public void btnCancel_Click(object sender, EventArgs e)
        {
            frmEvents secondForm = new frmEvents();
            secondForm.Show();
            this.Hide();
        }

        private void rdobtnGeneral_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnBalcony_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnVIP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnFindTix_Click(object sender, EventArgs e)
        {
            // variables, constants, strings needed
            const double GENERAL_PRICE = 35.00,
                               BALCONY_PRICE = 35.00,
                               VIP_PRICE = 70.00;
            const string FILENAME_PERM = "seatPermanentA.txt";
            int ticketsRequested, totalTicketsLeft, ticketOption = 0;
            double grandTotal;
            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;

            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());


            totalTicketsLeft = generalSeatsAvailable + balconySeatsAvailable + vipSeatsAvailable;


            //radio button being set to variable for switch case
            if (rdobtnGeneral.Checked)
            {
                ticketOption = 0;
            }
            else if (rdobtnBalcony.Checked)
            {
                ticketOption = 1;
            }
            else if (rdobtnVIP.Checked)
            {
                ticketOption = 2;
            }




            // *IMPORTANT* If statement that will only run if there are enough tickets *IMPORTANT*

            if (totalTicketsLeft == 0)
            {
                lblResults.Text = "Sorry! We're all sold out! Try checking out our other events!";
            }
            else
            {
                //Save the results to temp file to use after checkout is confirme
                //temp file created and written in this ELSE statement
                //assign numeric up&down value to variable
                ticketsRequested = Convert.ToInt32(numTix.Value);



                //switch cases for ticket options
                switch (ticketOption)

                {
                    case 0:
                        //If statement verifying tickets are available
                        if ((generalSeatsAvailable) > 0 && (ticketsRequested <= generalSeatsAvailable))
                        {
                            //Calculations for ticket total
                            grandTotal = ticketsRequested * GENERAL_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                        }
                        else if (generalSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for GA." +
                                               "Try another option!";
                        }
                        else if ((ticketsRequested > generalSeatsAvailable))
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less or try another seat section.";
                        }
                        break;
                    case 1:
                        if ((balconySeatsAvailable) > 0 && (ticketsRequested <= balconySeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * BALCONY_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));
                        }
                        else if (balconySeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for Balcony." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > balconySeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    case 2:
                        if ((vipSeatsAvailable) > 0 && (ticketsRequested <= vipSeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * VIP_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                        }
                        else if (vipSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for VIP." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > vipSeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    default:
                        break;


                }

            }
            //close perm
            reader.Close();
            inFile.Close();

            /*-----------------------------------------------------------------------------------*/
            //enable the checkout button
            btnCheckOut.Enabled = true;
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {

            /*---------------------------------------------------------------------------------------*/
            //disable radio buttons to not tamper with the checkout
            rdobtnBalcony.Enabled = false;
            rdobtnGeneral.Enabled = false;
            rdobtnVIP.Enabled = false;

			/*-------------------------------------------------------------------------------------*/
			//disable find tickets button
			btnFindTix.Enabled = false;
            /*-----------------------------------------------------------------------------------------*/

            //when button is clicked the checkout window will become visible
            lblCheckoutPage.Visible = true;
            lblCustomerInfo.Visible = true;
            lblName.Visible = true;
            lblEmail.Visible = true;
            txtName.Visible = true;
            txtEmail.Visible = true;
            lblBillingAddress.Visible = true;
            lblCountry.Visible = true;
            lblStreetAddress.Visible = true;
            txtCountry.Visible = true;
            txtStreet.Visible = true;
            lblCity.Visible = true;
            lblState.Visible = true;
            txtCity.Visible = true;
            txtState.Visible = true;
            lblZipCode.Visible = true;
            txtZip.Visible = true;
            lblPaymentInformation.Visible = true;
            lblExpirationDate.Visible = true;
            lblCardNumber.Visible = true;
            txtCardNum.Visible = true;
            dateExpirationDate.Visible = true;
            lblSecurityCode.Visible = true;
            txtSecurity.Visible = true;
            btnConfirm.Visible = true;

            /*-----------------------------------------------------------------------*/

            //creating temporary file for the tickets selected

            // variables, constants, strings needed
            const double GENERAL_PRICE = 35.00,
                               BALCONY_PRICE = 35.00,
                               VIP_PRICE = 70.00;
            const string FILENAME_PERM = "seatPermanentAB.txt",
                         FILENAME_TEMP = "seatTemporaryAB.txt";
            int ticketsRequested, totalTicketsLeft, ticketOption = 0;
            double grandTotal;

            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;

            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());

            totalTicketsLeft = generalSeatsAvailable + balconySeatsAvailable + vipSeatsAvailable;

            //radio button being set to variable for switch case
            if (rdobtnGeneral.Checked)
            {
                ticketOption = 0;
            }
            else if (rdobtnBalcony.Checked)
            {
                ticketOption = 1;
            }
            else if (rdobtnVIP.Checked)
            {
                ticketOption = 2;
            }

            // *IMPORTANT* If statement that will only run if there are enough tickets *IMPORTANT*

            if (totalTicketsLeft == 0)
            {
                lblResults.Text = "Sorry! We're all sold out! Try checking out our other events!";
            }
            else
            {
				//assign numeric up and down to variable
				ticketsRequested = Convert.ToInt32(numTix.Value);

				//write to the temporary file
				FileStream outFile = new FileStream(FILENAME_TEMP, FileMode.Create, FileAccess.Write);
				StreamWriter writer = new StreamWriter(outFile);


				//switch cases for ticket options
				switch (ticketOption)

                {
                    case 0:
                        //If statement verifying tickets are available
                        if ((generalSeatsAvailable) > 0 && (ticketsRequested <= generalSeatsAvailable))
                        {
                            //Calculations for ticket total
                            grandTotal = ticketsRequested * GENERAL_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                            //update available seating for general
                            generalSeatsAvailable = generalSeatsAvailable - ticketsRequested;

                        }
                        else if (generalSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for GA." +
                                               "Try another option!";
                        }
                        else if ((ticketsRequested > generalSeatsAvailable))
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less or try another seat section.";
                        }
                        break;
                    case 1:
                        if ((balconySeatsAvailable) > 0 && (ticketsRequested <= balconySeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * BALCONY_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                            //update available seating for general
                            balconySeatsAvailable = balconySeatsAvailable - ticketsRequested;
                        }
                        else if (balconySeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for Balcony." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > balconySeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    case 2:
                        if ((vipSeatsAvailable) > 0 && (ticketsRequested <= vipSeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * VIP_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                            //update available seating for general
                            vipSeatsAvailable = vipSeatsAvailable - ticketsRequested;

                        }
                        else if (vipSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for VIP." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > vipSeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    default:
                        break;

                }
                //Write the new numbers into the temporary file

                writer.WriteLine(generalSeatsAvailable);
                writer.WriteLine(balconySeatsAvailable);
                writer.WriteLine(vipSeatsAvailable);

                //Temporary file closes

                writer.Close();
                outFile.Close();

                //permanet file closes

                reader.Close();
                inFile.Close();
            }
        }
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            txtEmail.Enabled = true;
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            txtCountry.Enabled = true;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            txtSecurity.Enabled = true;
        }
        private void txtCountry_TextChanged(object sender, EventArgs e)
        {
            txtStreet.Enabled = true;
        }

        private void txtStreet_TextChanged(object sender, EventArgs e)
        {
            txtCity.Enabled = true;
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {
            txtState.Enabled = true;
        }

        private void txtState_TextChanged(object sender, EventArgs e)
        {
            txtZip.Enabled = true;
        }

        private void txtZip_TextChanged(object sender, EventArgs e)
        {
            txtCardNum.Enabled = true;
        }

        private void txtCardNum_TextChanged(object sender, EventArgs e)
        {
            //string variable needed
            string cardnum;

            //enable date picker
            dateExpirationDate.Enabled = true;

        }

        private void txtSecurity_TextChanged(object sender, EventArgs e)
        {
            btnConfirm.Enabled = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //variables and constants
            const string FILENAME_TEMP = "seatTemporaryAB.txt", FILENAME_PERM = "seatPermanentAB.txt";
            string general, balcony, vip;

            //open temp file
            FileStream inFile = new FileStream(FILENAME_TEMP, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            general = reader.ReadLine();
            balcony = reader.ReadLine();
            vip = reader.ReadLine();

            reader.Close();
            inFile.Close();

            //open perm file
            FileStream outFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            //read temp

            writer.WriteLine(general);
            writer.WriteLine(balcony);
            writer.WriteLine(vip);

            writer.Close();
            outFile.Close();

        }

		
	}
}
