﻿namespace Concert_Sales__Project_
{
    partial class frmTicketSalesBandJ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTicketSalesBandJ));
            this.numTix = new System.Windows.Forms.NumericUpDown();
            this.lblVIPAmount = new System.Windows.Forms.Label();
            this.lblBalconyVIP = new System.Windows.Forms.Label();
            this.lblGeneralAmount = new System.Windows.Forms.Label();
            this.dateExpirationDate = new System.Windows.Forms.DateTimePicker();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtSecurity = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblZipCode = new System.Windows.Forms.Label();
            this.lblStreetAddress = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtCardNum = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblExpirationDate = new System.Windows.Forms.Label();
            this.lblSecurityCode = new System.Windows.Forms.Label();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblCheckoutPage = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.lblGenAdminPrice = new System.Windows.Forms.Label();
            this.lblBalconyPrice = new System.Windows.Forms.Label();
            this.lblVipPrice = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnFindTix = new System.Windows.Forms.Button();
            this.lblActName = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblBillingAddress = new System.Windows.Forms.Label();
            this.lblPaymentInformation = new System.Windows.Forms.Label();
            this.lblCustomerInfo = new System.Windows.Forms.Label();
            this.lbltixamount = new System.Windows.Forms.Label();
            this.rdobtnVIP = new System.Windows.Forms.RadioButton();
            this.rdobtnBalcony = new System.Windows.Forms.RadioButton();
            this.rdobtnGeneral = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.lblGeneralPrice = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblSelectPrice = new System.Windows.Forms.Label();
            this.lblbackground2 = new System.Windows.Forms.Label();
            this.lblbackground = new System.Windows.Forms.Label();
            this.lblCreditType = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).BeginInit();
            this.SuspendLayout();
            // 
            // numTix
            // 
            resources.ApplyResources(this.numTix, "numTix");
            this.numTix.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numTix.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTix.Name = "numTix";
            this.numTix.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblVIPAmount
            // 
            resources.ApplyResources(this.lblVIPAmount, "lblVIPAmount");
            this.lblVIPAmount.BackColor = System.Drawing.Color.Silver;
            this.lblVIPAmount.Name = "lblVIPAmount";
            // 
            // lblBalconyVIP
            // 
            resources.ApplyResources(this.lblBalconyVIP, "lblBalconyVIP");
            this.lblBalconyVIP.BackColor = System.Drawing.Color.Silver;
            this.lblBalconyVIP.Name = "lblBalconyVIP";
            // 
            // lblGeneralAmount
            // 
            resources.ApplyResources(this.lblGeneralAmount, "lblGeneralAmount");
            this.lblGeneralAmount.BackColor = System.Drawing.Color.Silver;
            this.lblGeneralAmount.Name = "lblGeneralAmount";
            // 
            // dateExpirationDate
            // 
            resources.ApplyResources(this.dateExpirationDate, "dateExpirationDate");
            this.dateExpirationDate.MinDate = new System.DateTime(2018, 5, 3, 0, 0, 0, 0);
            this.dateExpirationDate.Name = "dateExpirationDate";
            this.dateExpirationDate.Value = new System.DateTime(2018, 5, 3, 1, 28, 34, 0);
            this.dateExpirationDate.ValueChanged += new System.EventHandler(this.dateExpirationDate_ValueChanged);
            // 
            // txtState
            // 
            resources.ApplyResources(this.txtState, "txtState");
            this.txtState.Name = "txtState";
            // 
            // txtStreet
            // 
            resources.ApplyResources(this.txtStreet, "txtStreet");
            this.txtStreet.Name = "txtStreet";
            // 
            // txtZip
            // 
            resources.ApplyResources(this.txtZip, "txtZip");
            this.txtZip.Name = "txtZip";
            // 
            // txtCity
            // 
            resources.ApplyResources(this.txtCity, "txtCity");
            this.txtCity.Name = "txtCity";
            // 
            // txtCountry
            // 
            resources.ApplyResources(this.txtCountry, "txtCountry");
            this.txtCountry.Name = "txtCountry";
            // 
            // txtSecurity
            // 
            resources.ApplyResources(this.txtSecurity, "txtSecurity");
            this.txtSecurity.Name = "txtSecurity";
            this.txtSecurity.UseSystemPasswordChar = true;
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.Name = "txtEmail";
            // 
            // lblState
            // 
            resources.ApplyResources(this.lblState, "lblState");
            this.lblState.BackColor = System.Drawing.Color.Silver;
            this.lblState.ForeColor = System.Drawing.Color.Black;
            this.lblState.Name = "lblState";
            // 
            // lblZipCode
            // 
            resources.ApplyResources(this.lblZipCode, "lblZipCode");
            this.lblZipCode.BackColor = System.Drawing.Color.Silver;
            this.lblZipCode.ForeColor = System.Drawing.Color.Black;
            this.lblZipCode.Name = "lblZipCode";
            // 
            // lblStreetAddress
            // 
            resources.ApplyResources(this.lblStreetAddress, "lblStreetAddress");
            this.lblStreetAddress.BackColor = System.Drawing.Color.Silver;
            this.lblStreetAddress.ForeColor = System.Drawing.Color.Black;
            this.lblStreetAddress.Name = "lblStreetAddress";
            // 
            // lblCity
            // 
            resources.ApplyResources(this.lblCity, "lblCity");
            this.lblCity.BackColor = System.Drawing.Color.Silver;
            this.lblCity.ForeColor = System.Drawing.Color.Black;
            this.lblCity.Name = "lblCity";
            // 
            // txtCardNum
            // 
            resources.ApplyResources(this.txtCardNum, "txtCardNum");
            this.txtCardNum.Name = "txtCardNum";
            this.txtCardNum.TextChanged += new System.EventHandler(this.txtCardNum_TextChanged_1);
            // 
            // txtName
            // 
            resources.ApplyResources(this.txtName, "txtName");
            this.txtName.Name = "txtName";
            // 
            // lblCountry
            // 
            resources.ApplyResources(this.lblCountry, "lblCountry");
            this.lblCountry.BackColor = System.Drawing.Color.Silver;
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Name = "lblCountry";
            // 
            // lblExpirationDate
            // 
            resources.ApplyResources(this.lblExpirationDate, "lblExpirationDate");
            this.lblExpirationDate.BackColor = System.Drawing.Color.LightGray;
            this.lblExpirationDate.ForeColor = System.Drawing.Color.Black;
            this.lblExpirationDate.Name = "lblExpirationDate";
            // 
            // lblSecurityCode
            // 
            resources.ApplyResources(this.lblSecurityCode, "lblSecurityCode");
            this.lblSecurityCode.BackColor = System.Drawing.Color.LightGray;
            this.lblSecurityCode.ForeColor = System.Drawing.Color.Black;
            this.lblSecurityCode.Name = "lblSecurityCode";
            // 
            // lblCardNumber
            // 
            resources.ApplyResources(this.lblCardNumber, "lblCardNumber");
            this.lblCardNumber.BackColor = System.Drawing.Color.LightGray;
            this.lblCardNumber.ForeColor = System.Drawing.Color.Black;
            this.lblCardNumber.Name = "lblCardNumber";
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.lblEmail.BackColor = System.Drawing.Color.LightGray;
            this.lblEmail.ForeColor = System.Drawing.Color.Black;
            this.lblEmail.Name = "lblEmail";
            // 
            // lblName
            // 
            resources.ApplyResources(this.lblName, "lblName");
            this.lblName.BackColor = System.Drawing.Color.LightGray;
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Name = "lblName";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.White;
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // lblCheckoutPage
            // 
            this.lblCheckoutPage.BackColor = System.Drawing.Color.Gainsboro;
            resources.ApplyResources(this.lblCheckoutPage, "lblCheckoutPage");
            this.lblCheckoutPage.ForeColor = System.Drawing.Color.Black;
            this.lblCheckoutPage.Name = "lblCheckoutPage";
            // 
            // lblFees
            // 
            resources.ApplyResources(this.lblFees, "lblFees");
            this.lblFees.BackColor = System.Drawing.Color.Silver;
            this.lblFees.Name = "lblFees";
            // 
            // lblGenAdminPrice
            // 
            resources.ApplyResources(this.lblGenAdminPrice, "lblGenAdminPrice");
            this.lblGenAdminPrice.BackColor = System.Drawing.Color.Silver;
            this.lblGenAdminPrice.Name = "lblGenAdminPrice";
            // 
            // lblBalconyPrice
            // 
            resources.ApplyResources(this.lblBalconyPrice, "lblBalconyPrice");
            this.lblBalconyPrice.BackColor = System.Drawing.Color.LightGray;
            this.lblBalconyPrice.Name = "lblBalconyPrice";
            // 
            // lblVipPrice
            // 
            resources.ApplyResources(this.lblVipPrice, "lblVipPrice");
            this.lblVipPrice.BackColor = System.Drawing.Color.Silver;
            this.lblVipPrice.Name = "lblVipPrice";
            // 
            // lblResults
            // 
            this.lblResults.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.lblResults, "lblResults");
            this.lblResults.Name = "lblResults";
            // 
            // btnConfirm
            // 
            resources.ApplyResources(this.btnConfirm, "btnConfirm");
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCheckOut
            // 
            resources.ApplyResources(this.btnCheckOut, "btnCheckOut");
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // btnCancel
            // 
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFindTix
            // 
            resources.ApplyResources(this.btnFindTix, "btnFindTix");
            this.btnFindTix.Name = "btnFindTix";
            this.btnFindTix.UseVisualStyleBackColor = true;
            this.btnFindTix.Click += new System.EventHandler(this.btnFindTix_Click);
            // 
            // lblActName
            // 
            this.lblActName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.lblActName, "lblActName");
            this.lblActName.ForeColor = System.Drawing.Color.Linen;
            this.lblActName.Name = "lblActName";
            // 
            // lblDate
            // 
            this.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.lblDate, "lblDate");
            this.lblDate.ForeColor = System.Drawing.Color.Linen;
            this.lblDate.Name = "lblDate";
            // 
            // lblBillingAddress
            // 
            this.lblBillingAddress.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.lblBillingAddress, "lblBillingAddress");
            this.lblBillingAddress.ForeColor = System.Drawing.Color.Black;
            this.lblBillingAddress.Name = "lblBillingAddress";
            // 
            // lblPaymentInformation
            // 
            this.lblPaymentInformation.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.lblPaymentInformation, "lblPaymentInformation");
            this.lblPaymentInformation.ForeColor = System.Drawing.Color.Black;
            this.lblPaymentInformation.Name = "lblPaymentInformation";
            // 
            // lblCustomerInfo
            // 
            this.lblCustomerInfo.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.lblCustomerInfo, "lblCustomerInfo");
            this.lblCustomerInfo.ForeColor = System.Drawing.Color.Black;
            this.lblCustomerInfo.Name = "lblCustomerInfo";
            // 
            // lbltixamount
            // 
            this.lbltixamount.BackColor = System.Drawing.Color.Gainsboro;
            resources.ApplyResources(this.lbltixamount, "lbltixamount");
            this.lbltixamount.ForeColor = System.Drawing.Color.Black;
            this.lbltixamount.Name = "lbltixamount";
            // 
            // rdobtnVIP
            // 
            resources.ApplyResources(this.rdobtnVIP, "rdobtnVIP");
            this.rdobtnVIP.BackColor = System.Drawing.Color.Silver;
            this.rdobtnVIP.ForeColor = System.Drawing.Color.Black;
            this.rdobtnVIP.Name = "rdobtnVIP";
            this.rdobtnVIP.TabStop = true;
            this.rdobtnVIP.UseVisualStyleBackColor = false;
            // 
            // rdobtnBalcony
            // 
            resources.ApplyResources(this.rdobtnBalcony, "rdobtnBalcony");
            this.rdobtnBalcony.BackColor = System.Drawing.Color.LightGray;
            this.rdobtnBalcony.ForeColor = System.Drawing.Color.Black;
            this.rdobtnBalcony.Name = "rdobtnBalcony";
            this.rdobtnBalcony.TabStop = true;
            this.rdobtnBalcony.UseVisualStyleBackColor = false;
            // 
            // rdobtnGeneral
            // 
            resources.ApplyResources(this.rdobtnGeneral, "rdobtnGeneral");
            this.rdobtnGeneral.BackColor = System.Drawing.Color.Silver;
            this.rdobtnGeneral.ForeColor = System.Drawing.Color.Black;
            this.rdobtnGeneral.Name = "rdobtnGeneral";
            this.rdobtnGeneral.TabStop = true;
            this.rdobtnGeneral.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // lblGeneralPrice
            // 
            this.lblGeneralPrice.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.lblGeneralPrice, "lblGeneralPrice");
            this.lblGeneralPrice.Name = "lblGeneralPrice";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.BackColor = System.Drawing.Color.Silver;
            resources.ApplyResources(this.lblSubTotal, "lblSubTotal");
            this.lblSubTotal.Name = "lblSubTotal";
            // 
            // lblSelectPrice
            // 
            this.lblSelectPrice.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.lblSelectPrice, "lblSelectPrice");
            this.lblSelectPrice.Name = "lblSelectPrice";
            // 
            // lblbackground2
            // 
            this.lblbackground2.BackColor = System.Drawing.Color.Gainsboro;
            resources.ApplyResources(this.lblbackground2, "lblbackground2");
            this.lblbackground2.Name = "lblbackground2";
            // 
            // lblbackground
            // 
            this.lblbackground.BackColor = System.Drawing.Color.Gainsboro;
            resources.ApplyResources(this.lblbackground, "lblbackground");
            this.lblbackground.Name = "lblbackground";
            // 
            // lblCreditType
            // 
            this.lblCreditType.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.lblCreditType, "lblCreditType");
            this.lblCreditType.Name = "lblCreditType";
            // 
            // frmTicketSalesBandJ
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.Controls.Add(this.lblCreditType);
            this.Controls.Add(this.numTix);
            this.Controls.Add(this.lblVIPAmount);
            this.Controls.Add(this.lblBalconyVIP);
            this.Controls.Add(this.lblGeneralAmount);
            this.Controls.Add(this.dateExpirationDate);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.txtSecurity);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblZipCode);
            this.Controls.Add(this.lblStreetAddress);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.txtCardNum);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.lblExpirationDate);
            this.Controls.Add(this.lblSecurityCode);
            this.Controls.Add(this.lblCardNumber);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblCheckoutPage);
            this.Controls.Add(this.lblFees);
            this.Controls.Add(this.lblGenAdminPrice);
            this.Controls.Add(this.lblBalconyPrice);
            this.Controls.Add(this.lblVipPrice);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnFindTix);
            this.Controls.Add(this.lblActName);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblBillingAddress);
            this.Controls.Add(this.lblPaymentInformation);
            this.Controls.Add(this.lblCustomerInfo);
            this.Controls.Add(this.lbltixamount);
            this.Controls.Add(this.rdobtnVIP);
            this.Controls.Add(this.rdobtnBalcony);
            this.Controls.Add(this.rdobtnGeneral);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblGeneralPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.lblSelectPrice);
            this.Controls.Add(this.lblbackground2);
            this.Controls.Add(this.lblbackground);
            this.Name = "frmTicketSalesBandJ";
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numTix;
        private System.Windows.Forms.Label lblVIPAmount;
        private System.Windows.Forms.Label lblBalconyVIP;
        private System.Windows.Forms.Label lblGeneralAmount;
        private System.Windows.Forms.DateTimePicker dateExpirationDate;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtSecurity;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblZipCode;
        private System.Windows.Forms.Label lblStreetAddress;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtCardNum;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblExpirationDate;
        private System.Windows.Forms.Label lblSecurityCode;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblCheckoutPage;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Label lblGenAdminPrice;
        private System.Windows.Forms.Label lblBalconyPrice;
        private System.Windows.Forms.Label lblVipPrice;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnFindTix;
        private System.Windows.Forms.Label lblActName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblBillingAddress;
        private System.Windows.Forms.Label lblPaymentInformation;
        private System.Windows.Forms.Label lblCustomerInfo;
        private System.Windows.Forms.Label lbltixamount;
        private System.Windows.Forms.RadioButton rdobtnVIP;
        private System.Windows.Forms.RadioButton rdobtnBalcony;
        private System.Windows.Forms.RadioButton rdobtnGeneral;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblGeneralPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblSelectPrice;
        private System.Windows.Forms.Label lblbackground2;
        private System.Windows.Forms.Label lblbackground;
        private System.Windows.Forms.Label lblCreditType;
    }
}