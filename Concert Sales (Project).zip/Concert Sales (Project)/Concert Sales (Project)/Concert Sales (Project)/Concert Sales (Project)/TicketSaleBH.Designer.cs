﻿namespace Concert_Sales__Project_
{
    partial class frmTicketSaleBH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numTix = new System.Windows.Forms.NumericUpDown();
            this.lblbackground = new System.Windows.Forms.Label();
            this.lbltixamount = new System.Windows.Forms.Label();
            this.lblSelectPrice = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblGeneralPrice = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rdobtnGeneral = new System.Windows.Forms.RadioButton();
            this.rdobtnBalcony = new System.Windows.Forms.RadioButton();
            this.rdobtnVIP = new System.Windows.Forms.RadioButton();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblActName = new System.Windows.Forms.Label();
            this.btnFindTix = new System.Windows.Forms.Button();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblVipPrice = new System.Windows.Forms.Label();
            this.lblBalconyPrice = new System.Windows.Forms.Label();
            this.lblGenAdminPrice = new System.Windows.Forms.Label();
            this.lblFees = new System.Windows.Forms.Label();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblCheckoutPage = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblCustomerInfo = new System.Windows.Forms.Label();
            this.lblBillingAddress = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblStreetAddress = new System.Windows.Forms.Label();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtStree = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.lblPaymentInformation = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCardNum = new System.Windows.Forms.TextBox();
            this.txtSecurity = new System.Windows.Forms.TextBox();
            this.lblbackground2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).BeginInit();
            this.SuspendLayout();
            // 
            // numTix
            // 
            this.numTix.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.numTix.ImeMode = System.Windows.Forms.ImeMode.On;
            this.numTix.Location = new System.Drawing.Point(197, 148);
            this.numTix.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numTix.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTix.Name = "numTix";
            this.numTix.Size = new System.Drawing.Size(112, 20);
            this.numTix.TabIndex = 9;
            this.numTix.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTix.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // lblbackground
            // 
            this.lblbackground.BackColor = System.Drawing.Color.Gainsboro;
            this.lblbackground.Location = new System.Drawing.Point(43, 142);
            this.lblbackground.Name = "lblbackground";
            this.lblbackground.Size = new System.Drawing.Size(410, 42);
            this.lblbackground.TabIndex = 10;
            this.lblbackground.Text = "(4 tickets max)";
            this.lblbackground.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lbltixamount
            // 
            this.lbltixamount.BackColor = System.Drawing.Color.Gainsboro;
            this.lbltixamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltixamount.ForeColor = System.Drawing.Color.Black;
            this.lbltixamount.Location = new System.Drawing.Point(43, 103);
            this.lbltixamount.Name = "lbltixamount";
            this.lbltixamount.Size = new System.Drawing.Size(410, 40);
            this.lbltixamount.TabIndex = 11;
            this.lbltixamount.Text = "How many tickets are you looking for?";
            this.lbltixamount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSelectPrice
            // 
            this.lblSelectPrice.BackColor = System.Drawing.Color.LightGray;
            this.lblSelectPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectPrice.Location = new System.Drawing.Point(43, 184);
            this.lblSelectPrice.Name = "lblSelectPrice";
            this.lblSelectPrice.Size = new System.Drawing.Size(410, 28);
            this.lblSelectPrice.TabIndex = 10;
            this.lblSelectPrice.Text = "Select Price Level";
            this.lblSelectPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 240);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(410, 28);
            this.label2.TabIndex = 10;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblGeneralPrice
            // 
            this.lblGeneralPrice.BackColor = System.Drawing.Color.Silver;
            this.lblGeneralPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneralPrice.Location = new System.Drawing.Point(43, 212);
            this.lblGeneralPrice.Name = "lblGeneralPrice";
            this.lblGeneralPrice.Size = new System.Drawing.Size(410, 28);
            this.lblGeneralPrice.TabIndex = 10;
            this.lblGeneralPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(410, 28);
            this.label4.TabIndex = 10;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rdobtnGeneral
            // 
            this.rdobtnGeneral.AutoSize = true;
            this.rdobtnGeneral.BackColor = System.Drawing.Color.Silver;
            this.rdobtnGeneral.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnGeneral.ForeColor = System.Drawing.Color.Black;
            this.rdobtnGeneral.Location = new System.Drawing.Point(55, 216);
            this.rdobtnGeneral.Name = "rdobtnGeneral";
            this.rdobtnGeneral.Size = new System.Drawing.Size(140, 20);
            this.rdobtnGeneral.TabIndex = 2;
            this.rdobtnGeneral.TabStop = true;
            this.rdobtnGeneral.Text = "General Admission";
            this.rdobtnGeneral.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnGeneral.UseVisualStyleBackColor = false;
            this.rdobtnGeneral.CheckedChanged += new System.EventHandler(this.rdobtnGeneral_CheckedChanged);
            // 
            // rdobtnBalcony
            // 
            this.rdobtnBalcony.AutoSize = true;
            this.rdobtnBalcony.BackColor = System.Drawing.Color.LightGray;
            this.rdobtnBalcony.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnBalcony.ForeColor = System.Drawing.Color.Black;
            this.rdobtnBalcony.Location = new System.Drawing.Point(55, 244);
            this.rdobtnBalcony.Name = "rdobtnBalcony";
            this.rdobtnBalcony.Size = new System.Drawing.Size(75, 20);
            this.rdobtnBalcony.TabIndex = 5;
            this.rdobtnBalcony.TabStop = true;
            this.rdobtnBalcony.Text = "Balcony";
            this.rdobtnBalcony.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnBalcony.UseVisualStyleBackColor = false;
            this.rdobtnBalcony.CheckedChanged += new System.EventHandler(this.rdobtnBalcony_CheckedChanged);
            // 
            // rdobtnVIP
            // 
            this.rdobtnVIP.AutoSize = true;
            this.rdobtnVIP.BackColor = System.Drawing.Color.Silver;
            this.rdobtnVIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdobtnVIP.ForeColor = System.Drawing.Color.Black;
            this.rdobtnVIP.Location = new System.Drawing.Point(55, 272);
            this.rdobtnVIP.Name = "rdobtnVIP";
            this.rdobtnVIP.Size = new System.Drawing.Size(47, 20);
            this.rdobtnVIP.TabIndex = 8;
            this.rdobtnVIP.TabStop = true;
            this.rdobtnVIP.Text = "VIP";
            this.rdobtnVIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rdobtnVIP.UseVisualStyleBackColor = false;
            this.rdobtnVIP.CheckedChanged += new System.EventHandler(this.rdobtnVIP_CheckedChanged);
            // 
            // lblDate
            // 
            this.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.Linen;
            this.lblDate.Location = new System.Drawing.Point(43, 22);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(85, 70);
            this.lblDate.TabIndex = 12;
            this.lblDate.Text = "MAY\r\n8";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblActName
            // 
            this.lblActName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblActName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActName.ForeColor = System.Drawing.Color.Linen;
            this.lblActName.Location = new System.Drawing.Point(218, 22);
            this.lblActName.Name = "lblActName";
            this.lblActName.Size = new System.Drawing.Size(235, 70);
            this.lblActName.TabIndex = 12;
            this.lblActName.Text = "BROCKHAMPTON";
            this.lblActName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnFindTix
            // 
            this.btnFindTix.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindTix.Location = new System.Drawing.Point(192, 314);
            this.btnFindTix.Name = "btnFindTix";
            this.btnFindTix.Size = new System.Drawing.Size(112, 23);
            this.btnFindTix.TabIndex = 13;
            this.btnFindTix.Text = "Find Tickets";
            this.btnFindTix.UseVisualStyleBackColor = true;
            this.btnFindTix.Click += new System.EventHandler(this.btnFindTix_Click);
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.BackColor = System.Drawing.Color.Silver;
            this.lblSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(43, 354);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(410, 58);
            this.lblSubTotal.TabIndex = 10;
            this.lblSubTotal.Text = "Order Total";
            this.lblSubTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.Silver;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(351, 376);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 16);
            this.lblTotal.TabIndex = 14;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVipPrice
            // 
            this.lblVipPrice.AutoSize = true;
            this.lblVipPrice.BackColor = System.Drawing.Color.Silver;
            this.lblVipPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVipPrice.Location = new System.Drawing.Point(353, 274);
            this.lblVipPrice.Name = "lblVipPrice";
            this.lblVipPrice.Size = new System.Drawing.Size(52, 16);
            this.lblVipPrice.TabIndex = 14;
            this.lblVipPrice.Text = "$70.00";
            this.lblVipPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBalconyPrice
            // 
            this.lblBalconyPrice.AutoSize = true;
            this.lblBalconyPrice.BackColor = System.Drawing.Color.LightGray;
            this.lblBalconyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalconyPrice.Location = new System.Drawing.Point(353, 246);
            this.lblBalconyPrice.Name = "lblBalconyPrice";
            this.lblBalconyPrice.Size = new System.Drawing.Size(52, 16);
            this.lblBalconyPrice.TabIndex = 14;
            this.lblBalconyPrice.Text = "$35.00";
            this.lblBalconyPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGenAdminPrice
            // 
            this.lblGenAdminPrice.AutoSize = true;
            this.lblGenAdminPrice.BackColor = System.Drawing.Color.Silver;
            this.lblGenAdminPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenAdminPrice.Location = new System.Drawing.Point(353, 218);
            this.lblGenAdminPrice.Name = "lblGenAdminPrice";
            this.lblGenAdminPrice.Size = new System.Drawing.Size(52, 16);
            this.lblGenAdminPrice.TabIndex = 14;
            this.lblGenAdminPrice.Text = "$35.00";
            this.lblGenAdminPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFees
            // 
            this.lblFees.AutoSize = true;
            this.lblFees.BackColor = System.Drawing.Color.Silver;
            this.lblFees.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFees.Location = new System.Drawing.Point(52, 394);
            this.lblFees.Name = "lblFees";
            this.lblFees.Size = new System.Drawing.Size(76, 12);
            this.lblFees.TabIndex = 15;
            this.lblFees.Text = "*All fees included";
            this.lblFees.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.Location = new System.Drawing.Point(341, 447);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(112, 23);
            this.btnCheckOut.TabIndex = 13;
            this.btnCheckOut.Text = "Checkout";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(43, 447);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblCheckoutPage
            // 
            this.lblCheckoutPage.BackColor = System.Drawing.Color.Gainsboro;
            this.lblCheckoutPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckoutPage.ForeColor = System.Drawing.Color.Black;
            this.lblCheckoutPage.Location = new System.Drawing.Point(648, 22);
            this.lblCheckoutPage.Name = "lblCheckoutPage";
            this.lblCheckoutPage.Size = new System.Drawing.Size(258, 45);
            this.lblCheckoutPage.TabIndex = 16;
            this.lblCheckoutPage.Text = "Checkout Page";
            this.lblCheckoutPage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.LightGray;
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(598, 109);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(57, 13);
            this.lblName.TabIndex = 18;
            this.lblName.Text = "Full Name:";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.LightGray;
            this.lblEmail.ForeColor = System.Drawing.Color.Black;
            this.lblEmail.Location = new System.Drawing.Point(804, 109);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(38, 13);
            this.lblEmail.TabIndex = 19;
            this.lblEmail.Text = "Email: ";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(598, 129);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(144, 20);
            this.txtName.TabIndex = 20;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(804, 129);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(144, 20);
            this.txtEmail.TabIndex = 21;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // lblCustomerInfo
            // 
            this.lblCustomerInfo.BackColor = System.Drawing.Color.LightGray;
            this.lblCustomerInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerInfo.ForeColor = System.Drawing.Color.Black;
            this.lblCustomerInfo.Location = new System.Drawing.Point(564, 83);
            this.lblCustomerInfo.Name = "lblCustomerInfo";
            this.lblCustomerInfo.Size = new System.Drawing.Size(426, 75);
            this.lblCustomerInfo.TabIndex = 11;
            this.lblCustomerInfo.Text = "Customer Information:";
            // 
            // lblBillingAddress
            // 
            this.lblBillingAddress.BackColor = System.Drawing.Color.Silver;
            this.lblBillingAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillingAddress.ForeColor = System.Drawing.Color.Black;
            this.lblBillingAddress.Location = new System.Drawing.Point(564, 158);
            this.lblBillingAddress.Name = "lblBillingAddress";
            this.lblBillingAddress.Size = new System.Drawing.Size(426, 185);
            this.lblBillingAddress.TabIndex = 11;
            this.lblBillingAddress.Text = "Billing Address:";
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.BackColor = System.Drawing.Color.Silver;
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(598, 186);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(46, 13);
            this.lblCountry.TabIndex = 18;
            this.lblCountry.Text = "Country:";
            this.lblCountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStreetAddress
            // 
            this.lblStreetAddress.AutoSize = true;
            this.lblStreetAddress.BackColor = System.Drawing.Color.Silver;
            this.lblStreetAddress.ForeColor = System.Drawing.Color.Black;
            this.lblStreetAddress.Location = new System.Drawing.Point(804, 186);
            this.lblStreetAddress.Name = "lblStreetAddress";
            this.lblStreetAddress.Size = new System.Drawing.Size(79, 13);
            this.lblStreetAddress.TabIndex = 19;
            this.lblStreetAddress.Text = "Street Address:";
            this.lblStreetAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCountry
            // 
            this.txtCountry.Location = new System.Drawing.Point(598, 209);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(144, 20);
            this.txtCountry.TabIndex = 20;
            this.txtCountry.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtStree
            // 
            this.txtStree.Location = new System.Drawing.Point(804, 209);
            this.txtStree.Name = "txtStree";
            this.txtStree.Size = new System.Drawing.Size(144, 20);
            this.txtStree.TabIndex = 21;
            this.txtStree.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Silver;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(598, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "City:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(598, 262);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(144, 20);
            this.txtCity.TabIndex = 20;
            this.txtCity.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Silver;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(804, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "State:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(804, 262);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(144, 20);
            this.txtState.TabIndex = 21;
            this.txtState.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Silver;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(598, 292);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Zip code:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(598, 315);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(144, 20);
            this.txtZip.TabIndex = 20;
            this.txtZip.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblPaymentInformation
            // 
            this.lblPaymentInformation.BackColor = System.Drawing.Color.LightGray;
            this.lblPaymentInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentInformation.ForeColor = System.Drawing.Color.Black;
            this.lblPaymentInformation.Location = new System.Drawing.Point(564, 343);
            this.lblPaymentInformation.Name = "lblPaymentInformation";
            this.lblPaymentInformation.Size = new System.Drawing.Size(426, 86);
            this.lblPaymentInformation.TabIndex = 11;
            this.lblPaymentInformation.Text = "Payment Information:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.LightGray;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(804, 357);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Card Number:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.LightGray;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(807, 402);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Security Code:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCardNum
            // 
            this.txtCardNum.Location = new System.Drawing.Point(804, 373);
            this.txtCardNum.Name = "txtCardNum";
            this.txtCardNum.Size = new System.Drawing.Size(144, 20);
            this.txtCardNum.TabIndex = 20;
            this.txtCardNum.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // txtSecurity
            // 
            this.txtSecurity.Location = new System.Drawing.Point(908, 403);
            this.txtSecurity.Name = "txtSecurity";
            this.txtSecurity.Size = new System.Drawing.Size(40, 20);
            this.txtSecurity.TabIndex = 21;
            this.txtSecurity.UseSystemPasswordChar = true;
            this.txtSecurity.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // lblbackground2
            // 
            this.lblbackground2.BackColor = System.Drawing.Color.Gainsboro;
            this.lblbackground2.Location = new System.Drawing.Point(43, 296);
            this.lblbackground2.Name = "lblbackground2";
            this.lblbackground2.Size = new System.Drawing.Size(410, 58);
            this.lblbackground2.TabIndex = 10;
            this.lblbackground2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(580, 396);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.MinDate = new System.DateTime(2018, 5, 3, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(198, 20);
            this.dateTimePicker1.TabIndex = 22;
            this.dateTimePicker1.Value = new System.DateTime(2018, 5, 3, 1, 28, 34, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.LightGray;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(579, 373);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Expiration Date:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(712, 447);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(131, 23);
            this.btnConfirm.TabIndex = 13;
            this.btnConfirm.Text = "Confirm Purchase";
            this.btnConfirm.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(503, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 448);
            this.label13.TabIndex = 17;
            this.label13.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n" +
    "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|";
            // 
            // frmTicketSaleBH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(1034, 521);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtStree);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.txtSecurity);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblStreetAddress);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCardNum);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblCheckoutPage);
            this.Controls.Add(this.lblFees);
            this.Controls.Add(this.lblGenAdminPrice);
            this.Controls.Add(this.lblBalconyPrice);
            this.Controls.Add(this.lblVipPrice);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.btnCheckOut);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnFindTix);
            this.Controls.Add(this.lblActName);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblBillingAddress);
            this.Controls.Add(this.lblPaymentInformation);
            this.Controls.Add(this.lblCustomerInfo);
            this.Controls.Add(this.lbltixamount);
            this.Controls.Add(this.numTix);
            this.Controls.Add(this.rdobtnVIP);
            this.Controls.Add(this.rdobtnBalcony);
            this.Controls.Add(this.rdobtnGeneral);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblGeneralPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSubTotal);
            this.Controls.Add(this.lblSelectPrice);
            this.Controls.Add(this.lblbackground2);
            this.Controls.Add(this.lblbackground);
            this.Name = "frmTicketSaleBH";
            this.Text = "Ticket Sales";
            this.Load += new System.EventHandler(this.frmTicketSaleBH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTix)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown numTix;
        private System.Windows.Forms.Label lblbackground;
        private System.Windows.Forms.Label lbltixamount;
        private System.Windows.Forms.Label lblSelectPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblGeneralPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdobtnGeneral;
        private System.Windows.Forms.RadioButton rdobtnBalcony;
        private System.Windows.Forms.RadioButton rdobtnVIP;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblActName;
        private System.Windows.Forms.Button btnFindTix;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblVipPrice;
        private System.Windows.Forms.Label lblBalconyPrice;
        private System.Windows.Forms.Label lblGenAdminPrice;
        private System.Windows.Forms.Label lblFees;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblCheckoutPage;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblCustomerInfo;
        private System.Windows.Forms.Label lblBillingAddress;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblStreetAddress;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtStree;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.Label lblPaymentInformation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCardNum;
        private System.Windows.Forms.TextBox txtSecurity;
        private System.Windows.Forms.Label lblbackground2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label label13;
    }
}