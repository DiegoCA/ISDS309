﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concert_Sales__Project_
{
    public partial class frmEvent1 : Form
    {
        public frmEvent1()
        {
            InitializeComponent();
        }

        private void lblArtistInformationBH_Click(object sender, EventArgs e)
        {

        }

        private void btnBuyTickets_Click(object sender, EventArgs e)
        {
            frmTicketSaleBH secondForm = new frmTicketSaleBH();
            secondForm.Show();
            this.Hide();
        }

        private void btnGoBack_Click(object sender, EventArgs e)
        {
            frmEvents thirdForm = new frmEvents();
            thirdForm.Show();
            this.Hide();
        }
    }
}
