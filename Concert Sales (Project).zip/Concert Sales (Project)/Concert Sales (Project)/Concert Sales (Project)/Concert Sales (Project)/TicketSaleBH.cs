﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concert_Sales__Project_
{
    public partial class frmTicketSaleBH : Form
    {
        public frmTicketSaleBH()
        {
            InitializeComponent();
            
        }

        enum TicketOptions
        {
            GENERAL, BALCONY, VIP
        }
            
        private void frmTicketSaleBH_Load(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmEvents secondForm = new frmEvents();
            secondForm.Show();
            this.Hide();
        }

        private void rdobtnGeneral_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnBalcony_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnVIP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            //variables, constants, and strings needed 
            const int; 

        }

        private void btnFindTix_Click(object sender, EventArgs e)
        {

        }
    }
}
