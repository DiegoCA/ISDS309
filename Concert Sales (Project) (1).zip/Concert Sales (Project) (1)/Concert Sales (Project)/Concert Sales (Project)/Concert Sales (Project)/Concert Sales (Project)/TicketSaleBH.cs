﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;
using System.IO;

namespace Concert_Sales__Project_
{
    public partial class frmTicketSaleBH : Form
    {
        public frmTicketSaleBH()
        {
            InitializeComponent();
            
        }
            
        private void frmTicketSaleBH_Load(object sender, EventArgs e)
        {

        }

        public void btnCancel_Click(object sender, EventArgs e)
        {
            frmEvents secondForm = new frmEvents();
            secondForm.Show();
            this.Hide();
        }

        private void rdobtnGeneral_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnBalcony_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnVIP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnFindTix_Click(object sender, EventArgs e)
        {

        }
        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            //variables, constants, strings needed
            const double GENERAL_PRICE = 35.00,
                         BALCONY_PRICE = 35.00,
                         VIP_PRICE = 70.00;
            const string FILENAME_PERM = "seatPerm.txt",
                         FILENAME_TEMP = "seatTemp.txt";
            int ticketOption, ticketAmount, generalAmount, balconyAmount, vipAmount, totalTickets;
            double grandTotal;

            //Counter
            generalAmount = 250;
            balconyAmount = 100;
            vipAmount = 50;
            totalTickets = generalAmount + balconyAmount + vipAmount;

            //Record starting counter in permanent file
            FileStream outFile = new FileStream(FILENAME_PERM, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);
            Write(generalAmount);
            Write(balconyAmount);
            Write(vipAmount);

            writer.Close();
            outFile.Close();

            while ((totalTickets > 0))
            {
                FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
               
                 


               

                //radio button being set to variable for switch case
                if (rdobtnGeneral.Checked)
                {
                    ticketOption = 0;
                }
                else if (rdobtnBalcony.Checked)
                {
                    ticketOption = 1;
                }
                else if (rdobtnVIP.Checked)
                {
                    ticketOption = 2;
                }

                //loop and switch cases for ticket sales
                ticketAmount = Convert.ToInt16(numTix);

            }
        }
    }
}
