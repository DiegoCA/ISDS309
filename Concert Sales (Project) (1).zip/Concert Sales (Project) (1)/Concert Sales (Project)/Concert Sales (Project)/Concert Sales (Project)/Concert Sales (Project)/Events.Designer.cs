﻿namespace Concert_Sales__Project_
{
    partial class frmEvents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEvents));
            this.picboxBH = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.lblBrockhampton = new System.Windows.Forms.Label();
            this.lblBHDate = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // picboxBH
            // 
            this.picboxBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picboxBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picboxBH.Image = ((System.Drawing.Image)(resources.GetObject("picboxBH.Image")));
            this.picboxBH.Location = new System.Drawing.Point(82, 53);
            this.picboxBH.Name = "picboxBH";
            this.picboxBH.Size = new System.Drawing.Size(193, 190);
            this.picboxBH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBH.TabIndex = 0;
            this.picboxBH.TabStop = false;
            this.picboxBH.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Location = new System.Drawing.Point(396, 53);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(190, 190);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Location = new System.Drawing.Point(396, 297);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(190, 190);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Location = new System.Drawing.Point(82, 297);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(190, 190);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnGoBack
            // 
            this.btnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoBack.Location = new System.Drawing.Point(570, 539);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(104, 28);
            this.btnGoBack.TabIndex = 1;
            this.btnGoBack.Text = "Go Back";
            this.btnGoBack.UseVisualStyleBackColor = true;
            this.btnGoBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblBrockhampton
            // 
            this.lblBrockhampton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBrockhampton.ForeColor = System.Drawing.Color.Linen;
            this.lblBrockhampton.Location = new System.Drawing.Point(79, 23);
            this.lblBrockhampton.Name = "lblBrockhampton";
            this.lblBrockhampton.Size = new System.Drawing.Size(193, 27);
            this.lblBrockhampton.TabIndex = 2;
            this.lblBrockhampton.Text = "BROCKHAMPTON";
            this.lblBrockhampton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBHDate
            // 
            this.lblBHDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBHDate.ForeColor = System.Drawing.Color.Linen;
            this.lblBHDate.Location = new System.Drawing.Point(79, 246);
            this.lblBHDate.Name = "lblBHDate";
            this.lblBHDate.Size = new System.Drawing.Size(193, 27);
            this.lblBHDate.TabIndex = 2;
            this.lblBHDate.Text = "5 / 8";
            this.lblBHDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBHDate.Click += new System.EventHandler(this.label1_Click);
            // 
            // frmEvents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.ClientSize = new System.Drawing.Size(686, 579);
            this.Controls.Add(this.lblBHDate);
            this.Controls.Add(this.lblBrockhampton);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.picboxBH);
            this.Name = "frmEvents";
            this.Text = "Events";
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picboxBH;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.Label lblBrockhampton;
        private System.Windows.Forms.Label lblBHDate;
    }
}