﻿namespace Concert_Sales__Project_
{
    partial class frmEvents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEvents));
            this.picboxBH = new System.Windows.Forms.PictureBox();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.lblBrockhampton = new System.Windows.Forms.Label();
            this.lblBHDate = new System.Windows.Forms.Label();
            this.lblAlinaBaraz = new System.Windows.Forms.Label();
            this.lblPanic = new System.Windows.Forms.Label();
            this.lblBeyonce = new System.Windows.Forms.Label();
            this.picBoxPanic = new System.Windows.Forms.PictureBox();
            this.picBoxBeyonce = new System.Windows.Forms.PictureBox();
            this.picBoxAlinaBaraz = new System.Windows.Forms.PictureBox();
            this.lblDateBey = new System.Windows.Forms.Label();
            this.lblDatePD = new System.Windows.Forms.Label();
            this.lblDateAB = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPanic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBeyonce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAlinaBaraz)).BeginInit();
            this.SuspendLayout();
            // 
            // picboxBH
            // 
            this.picboxBH.BackColor = System.Drawing.Color.Transparent;
            this.picboxBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picboxBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picboxBH.Image = ((System.Drawing.Image)(resources.GetObject("picboxBH.Image")));
            this.picboxBH.Location = new System.Drawing.Point(105, 70);
            this.picboxBH.Name = "picboxBH";
            this.picboxBH.Size = new System.Drawing.Size(216, 190);
            this.picboxBH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBH.TabIndex = 0;
            this.picboxBH.TabStop = false;
            this.picboxBH.Click += new System.EventHandler(this.picboxBH_Click);
            // 
            // btnGoBack
            // 
            this.btnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoBack.Location = new System.Drawing.Point(12, 12);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(76, 23);
            this.btnGoBack.TabIndex = 1;
            this.btnGoBack.Text = "Go Back";
            this.btnGoBack.UseVisualStyleBackColor = true;
            this.btnGoBack.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblBrockhampton
            // 
            this.lblBrockhampton.BackColor = System.Drawing.Color.Transparent;
            this.lblBrockhampton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblBrockhampton.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblBrockhampton.Location = new System.Drawing.Point(117, 40);
            this.lblBrockhampton.Name = "lblBrockhampton";
            this.lblBrockhampton.Size = new System.Drawing.Size(193, 27);
            this.lblBrockhampton.TabIndex = 2;
            this.lblBrockhampton.Text = "BROCKHAMPTON";
            this.lblBrockhampton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBHDate
            // 
            this.lblBHDate.BackColor = System.Drawing.Color.Transparent;
            this.lblBHDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBHDate.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblBHDate.Location = new System.Drawing.Point(117, 263);
            this.lblBHDate.Name = "lblBHDate";
            this.lblBHDate.Size = new System.Drawing.Size(193, 27);
            this.lblBHDate.TabIndex = 2;
            this.lblBHDate.Text = "MAY 8";
            this.lblBHDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAlinaBaraz
            // 
            this.lblAlinaBaraz.BackColor = System.Drawing.Color.Transparent;
            this.lblAlinaBaraz.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlinaBaraz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.lblAlinaBaraz.Location = new System.Drawing.Point(414, 40);
            this.lblAlinaBaraz.Name = "lblAlinaBaraz";
            this.lblAlinaBaraz.Size = new System.Drawing.Size(193, 27);
            this.lblAlinaBaraz.TabIndex = 7;
            this.lblAlinaBaraz.Text = "ALINA BARAZ";
            this.lblAlinaBaraz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanic
            // 
            this.lblPanic.BackColor = System.Drawing.Color.Transparent;
            this.lblPanic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanic.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(169)))), ((int)(((byte)(75)))));
            this.lblPanic.Location = new System.Drawing.Point(117, 324);
            this.lblPanic.Name = "lblPanic";
            this.lblPanic.Size = new System.Drawing.Size(193, 27);
            this.lblPanic.TabIndex = 8;
            this.lblPanic.Text = "PANIC! AT THE DISCO";
            this.lblPanic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBeyonce
            // 
            this.lblBeyonce.BackColor = System.Drawing.Color.Transparent;
            this.lblBeyonce.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeyonce.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(111)))), ((int)(((byte)(145)))));
            this.lblBeyonce.Location = new System.Drawing.Point(414, 324);
            this.lblBeyonce.Name = "lblBeyonce";
            this.lblBeyonce.Size = new System.Drawing.Size(193, 27);
            this.lblBeyonce.TabIndex = 9;
            this.lblBeyonce.Text = "BEYONCE AND JAY-Z";
            this.lblBeyonce.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picBoxPanic
            // 
            this.picBoxPanic.BackColor = System.Drawing.Color.Transparent;
            this.picBoxPanic.Image = ((System.Drawing.Image)(resources.GetObject("picBoxPanic.Image")));
            this.picBoxPanic.Location = new System.Drawing.Point(105, 354);
            this.picBoxPanic.Name = "picBoxPanic";
            this.picBoxPanic.Size = new System.Drawing.Size(216, 190);
            this.picBoxPanic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxPanic.TabIndex = 10;
            this.picBoxPanic.TabStop = false;
            this.picBoxPanic.Click += new System.EventHandler(this.picBoxPanic_Click);
            // 
            // picBoxBeyonce
            // 
            this.picBoxBeyonce.BackColor = System.Drawing.Color.Transparent;
            this.picBoxBeyonce.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBeyonce.Image")));
            this.picBoxBeyonce.Location = new System.Drawing.Point(402, 354);
            this.picBoxBeyonce.Name = "picBoxBeyonce";
            this.picBoxBeyonce.Size = new System.Drawing.Size(216, 190);
            this.picBoxBeyonce.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxBeyonce.TabIndex = 11;
            this.picBoxBeyonce.TabStop = false;
            this.picBoxBeyonce.Click += new System.EventHandler(this.picBoxBeyonce_Click);
            // 
            // picBoxAlinaBaraz
            // 
            this.picBoxAlinaBaraz.BackColor = System.Drawing.Color.Transparent;
            this.picBoxAlinaBaraz.Image = ((System.Drawing.Image)(resources.GetObject("picBoxAlinaBaraz.Image")));
            this.picBoxAlinaBaraz.Location = new System.Drawing.Point(402, 70);
            this.picBoxAlinaBaraz.Name = "picBoxAlinaBaraz";
            this.picBoxAlinaBaraz.Size = new System.Drawing.Size(216, 190);
            this.picBoxAlinaBaraz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxAlinaBaraz.TabIndex = 12;
            this.picBoxAlinaBaraz.TabStop = false;
            this.picBoxAlinaBaraz.Click += new System.EventHandler(this.picBoxAlinaBaraz_Click);
            // 
            // lblDateBey
            // 
            this.lblDateBey.AutoSize = true;
            this.lblDateBey.BackColor = System.Drawing.Color.Transparent;
            this.lblDateBey.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateBey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(111)))), ((int)(((byte)(145)))));
            this.lblDateBey.Location = new System.Drawing.Point(483, 547);
            this.lblDateBey.Name = "lblDateBey";
            this.lblDateBey.Size = new System.Drawing.Size(72, 20);
            this.lblDateBey.TabIndex = 13;
            this.lblDateBey.Text = "MAY 11";
            // 
            // lblDatePD
            // 
            this.lblDatePD.AutoSize = true;
            this.lblDatePD.BackColor = System.Drawing.Color.Transparent;
            this.lblDatePD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatePD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(169)))), ((int)(((byte)(75)))));
            this.lblDatePD.Location = new System.Drawing.Point(186, 547);
            this.lblDatePD.Name = "lblDatePD";
            this.lblDatePD.Size = new System.Drawing.Size(72, 20);
            this.lblDatePD.TabIndex = 14;
            this.lblDatePD.Text = "MAY 10";
            // 
            // lblDateAB
            // 
            this.lblDateAB.BackColor = System.Drawing.Color.Transparent;
            this.lblDateAB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateAB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.lblDateAB.Location = new System.Drawing.Point(460, 263);
            this.lblDateAB.Name = "lblDateAB";
            this.lblDateAB.Size = new System.Drawing.Size(100, 23);
            this.lblDateAB.TabIndex = 15;
            this.lblDateAB.Text = "MAY 9";
            this.lblDateAB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmEvents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(686, 579);
            this.Controls.Add(this.lblDateAB);
            this.Controls.Add(this.lblDatePD);
            this.Controls.Add(this.lblDateBey);
            this.Controls.Add(this.picBoxAlinaBaraz);
            this.Controls.Add(this.picBoxBeyonce);
            this.Controls.Add(this.picBoxPanic);
            this.Controls.Add(this.lblBeyonce);
            this.Controls.Add(this.lblPanic);
            this.Controls.Add(this.lblAlinaBaraz);
            this.Controls.Add(this.lblBHDate);
            this.Controls.Add(this.lblBrockhampton);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.picboxBH);
            this.Name = "frmEvents";
            this.Text = "Events";
            this.Load += new System.EventHandler(this.frmEvents_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPanic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBeyonce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAlinaBaraz)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picboxBH;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.Label lblBrockhampton;
        private System.Windows.Forms.Label lblBHDate;
        private System.Windows.Forms.Label lblAlinaBaraz;
        private System.Windows.Forms.Label lblPanic;
        private System.Windows.Forms.Label lblBeyonce;
        private System.Windows.Forms.PictureBox picBoxPanic;
        private System.Windows.Forms.PictureBox picBoxBeyonce;
        private System.Windows.Forms.PictureBox picBoxAlinaBaraz;
        private System.Windows.Forms.Label lblDateBey;
        private System.Windows.Forms.Label lblDatePD;
        private System.Windows.Forms.Label lblDateAB;
    }
}