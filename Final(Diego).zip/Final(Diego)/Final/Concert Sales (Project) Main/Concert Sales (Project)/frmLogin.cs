﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Concert_Sales__Project_
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            int counter;
            string username, password, line, nextLine;
            const string ADMIN_PASSWORD = "-999", ADMIN_USERNAME = "ADMIN";
            counter = 0;

            username = txtUsername.Text;
            password = txtPassword.Text;

            const string FILENAME2 = "customerPerm.txt";
            // create file stream and stream reader
            FileStream inFile = new FileStream(FILENAME2, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);


            ////load from file
            //username = reader.ReadLine();
            //password = reader.ReadLine();
            if ((username == ADMIN_USERNAME) && (password == ADMIN_PASSWORD))
            {
                frmAdmin secondForm = new frmAdmin();
                secondForm.Show();
                this.Hide();
 
            }
            else
                
                // find username then compares the next line to entered password 
            while ((line = reader.ReadLine()) != null)
            {


                    if (line.Contains(txtUsername.Text))
                        { 
                        nextLine = reader.ReadLine();
                        counter = 0;

                        if (nextLine == txtPassword.Text)
                            {
                            // check password on the next line
                            lblWelcome.Text = (counter.ToString() + ": " + line);
                            lblWelcome.Visible = true;
                            lblError.Visible = false;

                            // send the user info to form 1
                            frmMainPage secondForm = new frmMainPage();
                            secondForm.Show();
                            this.Hide();
                            break;
                             }
                        else
                        {
                            lblError.Visible = true;

                        }

                    }

            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmMainPage secondForm = new frmMainPage();
            secondForm.Show();
            this.Hide();

        }
    }
}
