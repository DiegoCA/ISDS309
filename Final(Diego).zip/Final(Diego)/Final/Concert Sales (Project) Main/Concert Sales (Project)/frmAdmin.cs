﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Concert_Sales__Project_
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {
            // Declare variables and constants
            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;
            double totalSales;
            const string FILENAME_PERM = "seatPermanentBH.txt";

            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            totalSales = Convert.ToDouble(reader.ReadLine());


            // Display results
            lblBHGA.Text = String.Format("{0}", generalSeatsAvailable);
            lblBHBALC.Text = String.Format("{0}", balconySeatsAvailable);
            lblBHVIP.Text = String.Format("{0}", vipSeatsAvailable);
            lblBHTotalSales.Text = string.Format("0", totalSales);

            reader.Close();
            inFile.Close();


            /*************************************************************************************/

            // Declare variables and constants
            int generalSeatsAvailable1, balconySeatsAvailable1, vipSeatsAvailable1;
            double totalSales1;
            const string FILENAME_PERM1 = "seatPermanentAB.txt";

            // Create filestream and streamreader
            FileStream inFile1 = new FileStream(FILENAME_PERM1, FileMode.Open, FileAccess.Read);
            StreamReader reader1 = new StreamReader(inFile1);

            // load from file
            generalSeatsAvailable1 = Convert.ToInt32(reader1.ReadLine());
            balconySeatsAvailable1 = Convert.ToInt32(reader1.ReadLine());
            vipSeatsAvailable1 = Convert.ToInt32(reader1.ReadLine());
            totalSales1 = Convert.ToDouble(reader1.ReadLine());


            // Display results
            lblABGD.Text = String.Format("{0}", generalSeatsAvailable1);
            lblABBALC.Text = String.Format("{0}", balconySeatsAvailable1);
            lblABVIP.Text = String.Format("{0}", vipSeatsAvailable1);
            lblABtotalSales.Text = string.Format("0", totalSales1);
            reader.Close();
            inFile1.Close();

            /******************************************************************/

            // Declare variables and constants
            int generalSeatsAvailable2, balconySeatsAvailable2, vipSeatsAvailable2;
            double totalSales2;
            const string FILENAME_PERM2 = "seatPermanentPATD.txt";

            // Create filestream and streamreader
            FileStream inFile2 = new FileStream(FILENAME_PERM2, FileMode.Open, FileAccess.Read);
            StreamReader reader2 = new StreamReader(inFile2);

            // load from file
            generalSeatsAvailable1 = Convert.ToInt32(reader2.ReadLine());
            balconySeatsAvailable1 = Convert.ToInt32(reader2.ReadLine());
            vipSeatsAvailable1 = Convert.ToInt32(reader2.ReadLine());
            totalSales1 = Convert.ToDouble(reader2.ReadLine());


            // Display results
            lblPADTGA.Text = String.Format("{0}", generalSeatsAvailable1);
            lblPATDBALC.Text = String.Format("{0}", balconySeatsAvailable1);
            lblPATDVIP.Text = String.Format("{0}", vipSeatsAvailable1);
            lblPATDTotalSales.Text = string.Format("0", totalSales1);
            reader.Close();
            inFile1.Close();

            /*********************************************************/
            // Declare variables and constants
            int generalSeatsAvailable3, balconySeatsAvailable3, vipSeatsAvailable3;
            double totalSales3;
            const string FILENAME_PERM3 = "seatPermanentBandJ.txt";

            // Create filestream and streamreader
            FileStream inFile3 = new FileStream(FILENAME_PERM3, FileMode.Open, FileAccess.Read);
            StreamReader reader3 = new StreamReader(inFile3);

            // load from file
            generalSeatsAvailable1 = Convert.ToInt32(reader3.ReadLine());
            balconySeatsAvailable1 = Convert.ToInt32(reader3.ReadLine());
            vipSeatsAvailable1 = Convert.ToInt32(reader3.ReadLine());
            totalSales1 = Convert.ToDouble(reader3.ReadLine());


            // Display results
            lblBANDJGA.Text = String.Format("{0}", generalSeatsAvailable1);
            lblBANDJBALC.Text = String.Format("{0}", balconySeatsAvailable1);
            lblBANDJVIP.Text = String.Format("{0}", vipSeatsAvailable1);
            lblBANDJTotalSales.Text = string.Format("0", totalSales1);
            reader.Close();
            inFile1.Close();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            frmMainPage secondForm = new frmMainPage();
            secondForm.Show();
            this.Hide();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            
            


        }

       
    }
       

      
    
}
