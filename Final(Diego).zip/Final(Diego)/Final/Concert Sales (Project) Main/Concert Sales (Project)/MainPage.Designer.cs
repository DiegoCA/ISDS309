﻿namespace Concert_Sales__Project_
{
    partial class frmMainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainPage));
            this.btnEvents = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnFAQ = new System.Windows.Forms.Button();
            this.lblTheaterName = new System.Windows.Forms.Label();
            this.tltpEvent = new System.Windows.Forms.ToolTip(this.components);
            this.tltpAbout = new System.Windows.Forms.ToolTip(this.components);
            this.tltpFAQ = new System.Windows.Forms.ToolTip(this.components);
            this.tltpMyAcct = new System.Windows.Forms.ToolTip(this.components);
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnSignUp = new System.Windows.Forms.Button();
            this.tltpSignUp = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // btnEvents
            // 
            this.btnEvents.BackColor = System.Drawing.Color.Transparent;
            this.btnEvents.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEvents.FlatAppearance.BorderColor = System.Drawing.Color.MidnightBlue;
            this.btnEvents.FlatAppearance.BorderSize = 0;
            this.btnEvents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvents.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvents.ForeColor = System.Drawing.Color.Linen;
            this.btnEvents.Location = new System.Drawing.Point(38, 423);
            this.btnEvents.Name = "btnEvents";
            this.btnEvents.Size = new System.Drawing.Size(75, 25);
            this.btnEvents.TabIndex = 4;
            this.btnEvents.Text = "EVENTS";
            this.btnEvents.UseVisualStyleBackColor = false;
            this.btnEvents.Click += new System.EventHandler(this.btnEvents_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.Transparent;
            this.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.Color.Linen;
            this.btnAbout.Location = new System.Drawing.Point(203, 423);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(75, 25);
            this.btnAbout.TabIndex = 4;
            this.btnAbout.Text = "ABOUT";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnFAQ
            // 
            this.btnFAQ.BackColor = System.Drawing.Color.Transparent;
            this.btnFAQ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFAQ.FlatAppearance.BorderSize = 0;
            this.btnFAQ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFAQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFAQ.ForeColor = System.Drawing.Color.Linen;
            this.btnFAQ.Location = new System.Drawing.Point(368, 423);
            this.btnFAQ.Name = "btnFAQ";
            this.btnFAQ.Size = new System.Drawing.Size(75, 25);
            this.btnFAQ.TabIndex = 4;
            this.btnFAQ.Tag = "";
            this.btnFAQ.Text = "FAQ";
            this.btnFAQ.UseVisualStyleBackColor = false;
            this.btnFAQ.Click += new System.EventHandler(this.btnFAQ_Click);
            // 
            // lblTheaterName
            // 
            this.lblTheaterName.BackColor = System.Drawing.Color.Transparent;
            this.lblTheaterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblTheaterName.ForeColor = System.Drawing.Color.Linen;
            this.lblTheaterName.Location = new System.Drawing.Point(62, 160);
            this.lblTheaterName.Name = "lblTheaterName";
            this.lblTheaterName.Size = new System.Drawing.Size(405, 62);
            this.lblTheaterName.TabIndex = 5;
            this.lblTheaterName.Text = "Titan Theater";
            this.lblTheaterName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tltpEvent
            // 
            this.tltpEvent.ToolTipTitle = "Find out more about our events";
            // 
            // tltpAbout
            // 
            this.tltpAbout.ToolTipTitle = "Click here to learn more about Titan Theater";
            // 
            // tltpFAQ
            // 
            this.tltpFAQ.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltpFAQ.ToolTipTitle = "Click here to view frequently asked questions";
            // 
            // tltpMyAcct
            // 
            this.tltpMyAcct.ToolTipTitle = "Click here to log into your account";
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.Linen;
            this.btnLogin.Location = new System.Drawing.Point(341, 24);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(126, 23);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "LOGIN";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnSignUp
            // 
            this.btnSignUp.BackColor = System.Drawing.Color.Transparent;
            this.btnSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUp.FlatAppearance.BorderSize = 0;
            this.btnSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp.ForeColor = System.Drawing.Color.Linen;
            this.btnSignUp.Location = new System.Drawing.Point(12, 24);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(199, 23);
            this.btnSignUp.TabIndex = 4;
            this.btnSignUp.Text = "CREATE ACCOUNT";
            this.btnSignUp.UseVisualStyleBackColor = false;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // tltpSignUp
            // 
            this.tltpSignUp.ToolTipTitle = "If you don\'t have an account, click here";
            // 
            // frmMainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(479, 517);
            this.Controls.Add(this.lblTheaterName);
            this.Controls.Add(this.btnFAQ);
            this.Controls.Add(this.btnSignUp);
            this.Controls.Add(this.btnAbout);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnEvents);
            this.Name = "frmMainPage";
            this.Text = "Titan Theater ";
            this.Load += new System.EventHandler(this.frmMainPage_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnEvents;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnFAQ;
        private System.Windows.Forms.Label lblTheaterName;
        private System.Windows.Forms.ToolTip tltpEvent;
        private System.Windows.Forms.ToolTip tltpAbout;
        private System.Windows.Forms.ToolTip tltpFAQ;
        private System.Windows.Forms.ToolTip tltpMyAcct;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnSignUp;
        private System.Windows.Forms.ToolTip tltpSignUp;
    }
}