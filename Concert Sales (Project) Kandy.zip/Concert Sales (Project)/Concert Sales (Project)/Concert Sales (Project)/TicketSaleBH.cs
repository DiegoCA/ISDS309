﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;
using System.IO;

namespace Concert_Sales__Project_
{
    public partial class frmTicketSaleBH : Form
    {
        public frmTicketSaleBH()
        {
            InitializeComponent();

        }

        private void frmTicketSaleBH_Load(object sender, EventArgs e)
        {
            // Declare variables and constants
            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;
            const string FILE_PERM = "seatPermanent.txt";
            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILE_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());

            // Display results
            lblTest.Text = String.Format("{0}  {1}  {2}", generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable);
        }

        public void btnCancel_Click(object sender, EventArgs e)
        {
            frmEvents secondForm = new frmEvents();
            secondForm.Show();
            this.Hide();
        }

        private void rdobtnGeneral_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnBalcony_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdobtnVIP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        
        private void btnFindTix_Click(object sender, EventArgs e)
        {
           // variables, constants, strings needed
            const double GENERAL_PRICE = 35.00,
                               BALCONY_PRICE = 35.00,
                               VIP_PRICE = 70.00;
            const string FILENAME_PERM = "seatPermanent.txt",
                         FILENAME_TEMP = "seatTemporary.txt";
            int ticketsRequested, totalTicketsLeft, ticketOption = 0;
            double grandTotal;

            int generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;
            const string FILE_NAME = "seatPermanent.txt";
            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            // load from file
            generalSeatsAvailable = Convert.ToInt32(reader.ReadLine());
            balconySeatsAvailable = Convert.ToInt32(reader.ReadLine());
            vipSeatsAvailable = Convert.ToInt32(reader.ReadLine());

            /* int[] generalSeatsAvailable, balconySeatsAvailable, vipSeatsAvailable;


            // Create filestream and streamreader
            FileStream inFile = new FileStream(FILENAME_PERM, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);

            int x = 0;

            while (reader.ReadLine() != null)
                ++x;

            int lines = x / 6;

            generalSeatsAvailable = new int[lines];
            balconySeatsAvailable = new int[lines];
            vipSeatsAvailable = new int[lines];

            for (int y = 0; y < lines; ++y)
            {
                generalSeatsAvailable[y] = Convert.ToInt32(reader.ReadLine());
                balconySeatsAvailable[y] = Convert.ToInt32(reader.ReadLine());
                vipSeatsAvailable[y] = Convert.ToInt32(reader.ReadLine());

            }

            for (int z = 0; z < lines; ++z)
                lblTest.Text += generalSeatsAvailable[z]; */

            //Permanent file is read
            //the numbers in the permanent file are assigned to generalSeats, balconySeats, etc. integer variables
            //once they are assigned
            //close permanent file



            totalTicketsLeft = generalSeatsAvailable + balconySeatsAvailable + vipSeatsAvailable;
           

            //radio button being set to variable for switch case
            if (rdobtnGeneral.Checked)
            {
                ticketOption = 0;
            }
            else if (rdobtnBalcony.Checked)
            {
                ticketOption = 1;
            }
            else if (rdobtnVIP.Checked)
            {
                ticketOption = 2;
            }




            // *IMPORTANT* If statement that will only run if there are enough tickets *IMPORTANT*

            if (totalTicketsLeft == 0)
            {
                lblResults.Text = "Sorry! We're all sold out! Try checking out our other events!";
            }
            else
            {
                //Save the results to temp file to use after checkout is confirme
                //temp file created and written in this ELSE statement
                //assign numeric up&down value to variable
                ticketsRequested = Convert.ToInt32(numTix.Value);

                //

                //switch cases for ticket options
                switch (ticketOption)

                {
                    case 0:
                        //If statement verifying tickets are available
                        if ((generalSeatsAvailable) > 0 && (ticketsRequested <= generalSeatsAvailable))
                        {
                            //Calculations for ticket total
                            grandTotal = ticketsRequested * GENERAL_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));

                           
                        }
                        else if (generalSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for GA." +
                                               "Try another option!";
                        }
                        else if ((ticketsRequested > generalSeatsAvailable))
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less or try another seat section.";
                        }
                        break;
                    case 1:
                        if ((balconySeatsAvailable) > 0 && (ticketsRequested <= balconySeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * BALCONY_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));
                        }
                        else if (balconySeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for Balcony." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > balconySeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    case 2:
                        if ((vipSeatsAvailable) > 0 && (ticketsRequested <= vipSeatsAvailable))
                        {
                            //Calculations for ticket total 
                            grandTotal = ticketsRequested * VIP_PRICE;
                            lblResults.Text = Convert.ToString(grandTotal.ToString("C"));
                        }
                        else if (vipSeatsAvailable == 0)
                        {
                            lblResults.Text = "Sorry! There are no more tickets left for VIP." +
                                              "Try another option!";
                        }
                        else if (ticketsRequested > vipSeatsAvailable)
                        {
                            lblResults.Text = "Sorry! The amount of tickets you want are not" +
                                                "available. Order less.";
                        }
                        break;
                    default:
                        break;
                       
               
                }

                //Write the new numbers into the temporary file



                //Temporary file closes
                //permanet file closes
            }
           
        }
        
        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            /*
          
            */
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //open temp file
            //open perm file
            //read temp
            //write temp numbers to perm file
            //read perm files
            //close temp
            //close perm
        }
    }
}

  

